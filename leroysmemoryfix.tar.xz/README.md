# ⚖️ Accountability Agent

A **secure, BYOK, persistent-memory legal case analysis agent** — a Flask web app that helps under-resourced defendants get the same quality of case analysis that money can buy.

> **This tool is not a lawyer.** It is a research and analysis assistant. All output must be reviewed by a human before being used in any legal proceeding.

---

## What It Does

1. **Ingest case files** — PDFs, .txt, .md documents
2. **Build persistent memory per case** — every fact, document, entity, and conversation thread is stored and recalled across sessions
3. **Research law** — search for relevant statutes, case law, and precedents using Brave Search API
4. **Analyze evidence** — identify contradictions in police reports, flag timeline inconsistencies, spot missing evidence
5. **Draft legal documents** — motions, briefs, cross-examination questions, defense strategy outlines
6. **Track case status** — deadlines, hearings, filings, timeline events
7. **Explain everything at an 8th-grade reading level** — so defendants and their families actually understand what's happening

---

## Quick Start

```bash
# 1. Clone and install
git clone https://github.com/Leerrooy95/Legal_Assistant.git
cd Legal_Assistant
pip install -r requirements.txt

# 2. (Optional) Copy and edit environment config
cp .env.example .env

# 3. Run the app
python app.py
# Opens at http://127.0.0.1:5000
```

On first launch, you'll be prompted to create a master password. This password:
- Protects all access to the tool
- Derives the encryption key for the database (when SQLCipher is installed)
- Cannot be recovered — store it securely

After setting the password, enter your **API keys** (BYOK):
- **Anthropic API Key** (required) — for Claude AI analysis
- **Brave Search API Key** (optional) — for legal research and fact-checking

---

## Tech Stack

| Layer | Technology | Why |
|-------|-----------|-----|
| Web framework | Flask 3.x | Battle-tested, lightweight |
| AI backbone | Anthropic Claude (Messages API) | BYOK, powerful analysis |
| Web search | Brave Search API | Legal research, fact verification |
| Entity extraction | GLiNER2 (local, zero-cost) | Extract people, statutes, dates |
| PDF processing | pdfplumber | Best Python PDF text extraction |
| Readability | Textstat (Flesch-Kincaid) | Plain language translation |
| Database | SQLite (+ optional SQLCipher encryption) | Zero-config, encrypted at rest |
| Authentication | bcrypt + Flask sessions | Single-user, secure |
| Frontend | HTML/CSS/JS (Jinja2 templates) | No framework overhead |

---

## Project Structure

```
├── app.py                     # Flask application entry point
├── auth.py                    # Master password authentication
├── config.py                  # App configuration
├── models.py                  # SQLite database models & operations
├── chat_engine.py             # Claude conversation engine
├── memory_manager.py          # Per-case context assembly
├── document_processor.py      # PDF/txt/md ingestion
├── legal_researcher.py        # Brave Search + Claude research
├── fact_checker.py            # Claim verification engine
├── entity_extractor.py        # GLiNER2 entity extraction
├── plain_language.py          # Readability translation engine
├── requirements.txt           # Python dependencies
├── .env.example               # Environment variable template
├── render.yaml                # Optional Render deployment
├── templates/                 # Jinja2 HTML templates
│   ├── base.html              # Shared layout
│   ├── login.html             # Login page
│   ├── setup.html             # First-run password setup
│   ├── api_keys.html          # BYOK API key entry
│   ├── dashboard.html         # Case list / overview
│   ├── case.html              # Case view (chat + docs + timeline)
│   └── upload.html            # Document upload
├── static/
│   ├── styles.css             # Dark theme styling
│   └── app.js                 # Frontend interactivity
├── data/                      # Database (gitignored)
├── uploads/                   # Uploaded files (gitignored)
├── tests/                     # Test suite
└── .github/workflows/
    └── validate.yml           # CI: lint, compile, test, secrets scan
```

---

## Chat Modes

| Mode | What It Does |
|------|-------------|
| **Analysis** | Deep case analysis, contradiction detection, strategy |
| **Research** | Brave Search + Claude legal research (statutes, case law) |
| **Drafting** | Legal document generation (motions, briefs, letters) |
| **Plain Language** | 8th-grade readability explanations |
| **Fact Check** | Verify claims against web sources |

---

## Security

- **Single-user access** — master password, no multi-user attack surface
- **BYOK** — API keys stored in encrypted session cookies, never on disk
- **Database encryption** — SQLCipher AES-256 (optional, requires `sqlcipher3-binary`)
- **Security headers** — CSP, X-Frame-Options, X-Content-Type-Options, Referrer-Policy
- **File upload safety** — extension whitelist, size limits, hashed filenames
- **Session expiry** — 2-hour timeout, HttpOnly/SameSite/Secure cookies
- **Secrets scanning** — CI checks for hardcoded secrets

---

## Deployment Options

### Local (Recommended)
```bash
python app.py
```
All data stays on your machine. No internet exposure.

### Render (Remote Access)
Push to GitHub, connect to Render, set `FLASK_SECRET_KEY` as an environment variable. See `render.yaml`.

---

## Legal & Ethical Considerations

See [Archive/LEGAL_AND_ETHICS.md](Archive/LEGAL_AND_ETHICS.md) for detailed information on:
- Attorney-client privilege (US v. Heppner, Feb 2026)
- ABA Formal Opinion 512
- State-specific rules
- Bias and hallucination mitigation
- Ethical use guidelines

---

## Contributing

This is a personal tool for case advocacy work. If you'd like to contribute or adapt it for your own use, please read the legal and ethical guidelines first.

---

## License

This project is for personal use. All output must be reviewed by a qualified human before being used in any legal proceeding.
