"""
config.py — Accountability Agent Configuration
================================================
Central configuration for Flask app, database paths, upload settings,
and session management.
"""

import os
import secrets
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent


class Config:
    """Flask application configuration."""

    # Flask core
    SECRET_KEY = os.environ.get("FLASK_SECRET_KEY") or secrets.token_hex(32)

    # Database
    DATABASE_PATH = os.environ.get(
        "DATABASE_PATH", str(BASE_DIR / "data" / "accountability.db")
    )

    # File uploads
    UPLOAD_DIR = os.environ.get("UPLOAD_DIR", str(BASE_DIR / "uploads"))
    MAX_UPLOAD_SIZE_MB = int(os.environ.get("MAX_UPLOAD_SIZE_MB", "50"))
    MAX_CONTENT_LENGTH = MAX_UPLOAD_SIZE_MB * 1024 * 1024
    ALLOWED_EXTENSIONS = {"pdf", "txt", "md"}

    # Session
    SESSION_LIFETIME_HOURS = int(os.environ.get("SESSION_LIFETIME_HOURS", "2"))
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Strict"
    SESSION_COOKIE_SECURE = os.environ.get("FLASK_ENV") == "production"

    # Rate limiting
    RATELIMIT_DEFAULT = "60/minute"
    RATELIMIT_LOGIN = "10/minute"
    RATELIMIT_CHAT = "30/minute"

    # Anthropic
    ANTHROPIC_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6")
    ANTHROPIC_MAX_TOKENS = int(os.environ.get("ANTHROPIC_MAX_TOKENS", "4096"))

    # Brave Search
    BRAVE_SEARCH_URL = "https://api.search.brave.com/res/v1/web/search"
    BRAVE_MAX_RESULTS = 10

    # Password hash file (stores bcrypt hash of master password)
    PASSWORD_HASH_FILE = str(BASE_DIR / "data" / ".password_hash")
