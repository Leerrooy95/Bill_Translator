# Leroy's Web Development — Live Trackers Pipeline

> A plain-English walkthrough of the full automation pipeline packaged in `leroyswebdevelopment.tar.xz`, written for someone who wants to understand what it does, why it works, and how to stand it up from scratch.

---

## What Is This?

**Live Trackers** is a fully automated, serverless intelligence pipeline. It runs entirely inside **GitHub Actions** on a schedule — no servers to manage, no databases to provision, nothing to keep running. Twice a day it wakes up, queries several AI APIs, crunches the results, publishes a static dashboard to GitHub Pages, and goes back to sleep.

The pipeline monitors a set of **leverage nodes** — geopolitical, financial, and informational pressure points — tracks signals across them, spots convergence patterns, verifies facts with Anthropic Claude, and produces a three-column rhetoric-vs-reality analysis. All output lands on a live dashboard at your custom domain.

---

## The 34-File Package at a Glance

```
leroyswebdevelopment/
├── 10 Python pipeline scripts
├── run_pipeline.sh            (local orchestrator)
├── 3 GitHub Actions workflows
├── scripts/sync_context_index.py
├── docs/index.html            (static dashboard)
├── tracker_config.json        (all nodes, signals, disambiguation)
├── requirements*.txt
├── .env.example
├── docs/                      (GitHub Pages root)
├── output/                    (pipeline output — gitignored, force-added by CI)
└── _AI_CONTEXT_INDEX/         (AI knowledge base, synced from parent project)
```

---

## Pipeline Architecture

The pipeline runs in **10 stages** (numbered 1 through 8, with two half-stages). Every stage is a standalone Python script; they communicate only through JSON files in `output/`.

```
Brave Search API
      │
      ▼
┌─────────────────┐     ┌──────────────────────┐
│ node_tracker.py │────▶│ entity_extractor.py  │
│  Stage 1        │     │  Stage 2             │
│  (Brave Search  │     │  (GLiNER2 local +    │
│   + Claude)     │     │   Llama Scout API)   │
└─────────────────┘     └──────────────────────┘
        │                         │
        ▼                         ▼
node_status.json        extracted_entities.json

convergence_detector.py (Stage 3) ──▶ convergence_report.json

Brave Search API
      │
      ▼
┌─────────────────────────┐     ┌───────────────────────────┐     ┌────────────────────────┐
│  daily_intelligence.py  │────▶│   fact_checker.py         │────▶│  rhetoric_reality.py   │
│  Stage 4                │     │   Stage 5                 │     │  Stage 6               │
│  (Brave Search + Claude)│     │   (Brave Search + Claude  │     │  (Anthropic Claude)    │
└─────────────────────────┘     │    + inline date/dollar   │     └────────────────────────┘
        │                       │    triage + dedup)         │              │
        ▼                       └───────────────────────────┘              ▼
daily_intelligence.json                 │                       rhetoric_reality.json
live_verification.json                  ▼
                                fact_check.json
                                                                           │
                                                                           ▼
build_kb_context.py (Stage 6.5) ──▶ entity_kb_context.json
                                ──▶ _AI_CONTEXT_INDEX/12_ENTITY_GRAPH.md
                                ──▶ _AI_CONTEXT_INDEX/13_RHETORIC_VS_REALITY.md

validate_pipeline.py  (Stage 7)   ──▶ pipeline_validation.json (non-blocking)
build_chart_data.py   (Stage 7.5) ──▶ chart_data.json
graph_builder.py      (Stage 8)   ──▶ docs/data/entity_graph.html

All output/ files ──▶ docs/data/ ──▶ GitHub Pages ──▶ your-domain.example.com
```

---

### Claude Models

| Stage | Script | Model |
|-------|--------|-------|
| 1 | `node_tracker.py` | `claude-sonnet-4-20250514` |
| 4 | `daily_intelligence.py` | `claude-sonnet-4-20250514` |
| 5 | `fact_checker.py` | `claude-sonnet-4-6` |
| 6 | `rhetoric_reality.py` | `claude-sonnet-4-6` |

Stages 1 and 4 (search + analysis) use `claude-sonnet-4-20250514`. Stages 5 and 6 (fact-checking + rhetoric analysis) use `claude-sonnet-4-6` (training cutoff January 2026). To change the model for any stage, edit the `_ANTHROPIC_MODEL` or `_MODEL` constant at the top of the relevant script.

---

## Stage-by-Stage Breakdown

### Stage 1 — `node_tracker.py` (Brave Search + Claude)

**What it does:** Queries Brave Search API for web results, then feeds them to Anthropic Claude for the live status of every **leverage node** defined in `tracker_config.json`. Each node gets classified as `FRICTION`, `COMPLIANCE`, `ESCALATION`, or `DE_ESCALATION`. Entity disambiguation rules in the config prevent the model from conflating similarly named organisations. The prompt template includes a **Regulatory Capture / Personnel** section that instructs Claude to always check for government advisory appointments, revolving-door moves between government and tracked entities, and executive orders that directly name or benefit tracked entities — flagging these in `under_radar_flags` even when they are not the primary headline.

**Output:** `output/node_status.json` + a timestamped copy in `output/history/`

**Failure behavior:** Hard stop — nothing downstream is meaningful without node data. If all API calls fail, falls back to the most recent historical tracker file.

**API used:** Brave Search (`BRAVE_API_KEY`) + Anthropic Claude (`ANTHROPIC_API_KEY`)

---

### Stage 2 — `entity_extractor.py` (GLiNER2 + Llama Scout)

**What it does:** Sends node status text through a dual extraction engine:
- **GLiNER2** — runs locally, zero API cost, extracts named entities from text
- **Llama Scout 17B** — called via GitHub Models API, produces structured JSON with entities, relationships, temporal markers, and cross-node links. When available, Llama Scout is primary; GLiNER2 serves as fallback.

Disambiguates extracted entity names against the canonical list in `tracker_config.json` (case-insensitive partial matching).

**Output:** `output/extracted_entities.json`

**Failure behavior:** Non-blocking (`continue-on-error: true` in CI). Pipeline continues with whatever data exists.

**API used:** GitHub Models (`LLAMA_SCOUT_KEY`, optional)

---

### Stage 3 — `convergence_detector.py` (local analysis)

**What it does:** Reads `output/history/tracker_*.json` files and detects **convergence patterns** — windows where 3 or more nodes show simultaneous activity within a 7-day window (the thermostat model's median lag). Also identifies friction↔compliance pairs — where one node is in friction and another in compliance at the same time.

**Output:** `output/convergence_report.json`

**Failure behavior:** Non-blocking.

**API used:** None (local computation only)

---

### Stage 4 — `daily_intelligence.py` (Brave Search — three-pass)

**What it does:** The most complex stage. Runs a **three-pass intelligence protocol**:

1. **Pass 1 — Signal sweep**: Queries each active signal individually so no single signal can dominate the output. Uses prompt engineering to prevent "contamination" — if >60% of breaking news comes from one signal, `detect_contamination()` flags it and triggers re-queries of under-represented signals.

2. **Pass 2 — Cross-node convergence scan**: Looks for stories that span multiple nodes simultaneously.

3. **Pass 3 — Under-radar probe**: Actively seeks stories that are not yet in mainstream coverage.

Optionally manages `PENDING_PREDICTIONS` (active forecasts being tracked) and `RESOLVED_PREDICTIONS` (audit trail of completed forecasts). These lists ship empty in the template — add your own predictions or leave empty to skip verification.

**Output:** `output/daily_intelligence.json`, `output/live_verification.json`, timestamped history

**Failure behavior:** Non-blocking (with warning).

**API used:** Brave Search (`BRAVE_API_KEY`) + Anthropic Claude (`ANTHROPIC_API_KEY`)

---

### Stage 5 — `fact_checker.py` (Anthropic Claude + Brave Search + inline triage)

**What it does:** Three-phase editorial review:

1. **Inline date/dollar triage** — Before verification, the fact checker runs date and dollar attribution triage on all claims (logic absorbed from the former `brave_postprocess.py` Stage 1.5 — no separate intermediate file is written). Future dates and dates outside the ±7-day window are flagged. Ambiguous dollar attributions found by entity extraction are marked for priority verification.

2. **Web verification evidence** — Queries **Brave Search** for each substantive claim (up to 30 searches per run). The search results are injected alongside each claim in the verification prompt so Claude can cross-reference its training knowledge against live web evidence. Web results take precedence for recent events.

3. **Verify + Correct** — Sends the enriched, deduplicated claims to **Anthropic Claude Sonnet**, which flags incorrect dates, misattributed actions, and fabricated events. Claims are **deduplicated** using normalized headline matching (SequenceMatcher >0.70 threshold) before verification to avoid checking the same content twice. Each claim tracks all source locations so corrections propagate to every upstream file that carried the claim. Applies **corrections in-place** so the dashboard always shows verified content.

4. **Enrich** — Identifies nodes/signals where upstream search returned nothing useful and fills in baseline context from Claude's training knowledge so the dashboard is never left blank.

Reads `standing_entity_corrections` from `tracker_config.json` and injects them into the verification prompt — this prevents the model from over-applying stale entity definitions. Corrections are fully data-driven: add new entries to the config file and the fact checker picks them up automatically (no code changes needed).

**Output:** `output/fact_check.json`

**Failure behavior:** Non-blocking. If `BRAVE_API_KEY` is not set, falls back to Claude's training knowledge only (no web evidence).

**API used:** Anthropic (`ANTHROPIC_API_KEY`) + Brave Search (`BRAVE_API_KEY`, optional but recommended)

---

### Stage 6 — `rhetoric_reality.py` (Anthropic Claude)

**What it does:** Reads all pipeline outputs and asks Claude to produce a **three-column gap analysis** for each active development:
- **Rhetoric column**: What officials or public figures said
- **Reality column**: What filings, documents, and data actually show
- **Domestic cost column**: What Americans pay for the gap

Tracks institutional bypass (which regulations/laws are altered or circumvented), ideological drivers, and cross-node convergence notes. Confidence levels: HIGH / MEDIUM / LOW per development.

**Output:** `output/rhetoric_reality.json`

**Failure behavior:** Non-blocking.

**API used:** Anthropic (`ANTHROPIC_API_KEY`)

---

### Stage 6.5 — `build_kb_context.py` (single run)

**What it does:** Runs once after rhetoric/reality analysis, ingesting entity data, convergence data, and rhetoric/reality output. Generates:
- `_AI_CONTEXT_INDEX/12_ENTITY_GRAPH.md` — entity inventory, relationships, cross-node connections, convergence events
- `_AI_CONTEXT_INDEX/13_RHETORIC_VS_REALITY.md` — rhetoric vs. reality analysis for the AI agent
- `output/entity_kb_context.json` — structured JSON summary

**Output:** `_AI_CONTEXT_INDEX/12_ENTITY_GRAPH.md`, `_AI_CONTEXT_INDEX/13_RHETORIC_VS_REALITY.md`, `output/entity_kb_context.json`

**Failure behavior:** Non-blocking.

**API used:** None (local computation only)

---

### Stage 7 — `validate_pipeline.py` (local, non-blocking)

**What it does:** Cross-pipeline consistency validation — no API calls. Checks:
1. `CRITICAL` nodes appear in `top_3_developments` or `breaking_news`
2. Source diversity (warns if all sources are the same type)
3. Signal contamination (flags when one signal dominates breaking news)
4. Convergence events have entity overlap across active nodes

**Output:** `output/pipeline_validation.json`

**Failure behavior:** Non-blocking (logs warnings, never stops the pipeline).

**API used:** None

---

### Stage 7.5 — `build_chart_data.py` (local analysis)

**What it does:** Aggregates the full run history from `output/history/` into chart-ready JSON for the dashboard's Charts tab.

**Output:** `output/chart_data.json`

**Failure behavior:** Non-blocking.

**API used:** None (local computation only)

---

### Stage 8 — `graph_builder.py` (NetworkX + PyVis)

**What it does:** Reads `extracted_entities.json` and builds a **directed** interactive HTML entity relationship graph using NetworkX (graph logic) and PyVis (rendering). Relationship arrows preserve the directionality captured by entity extraction (`from` → `to`). The graph is exported to `docs/data/entity_graph.html` and served directly from the dashboard.

**Output:** `docs/data/entity_graph.html`

**Failure behavior:** Non-blocking.

**API used:** None (local computation only)

---

## GitHub Actions Workflows

Three workflows ship with the package. They run on GitHub's free hosted runners — no infrastructure required.

### `run_pipeline.yml` — The Main Engine

| Setting | Value |
|---------|-------|
| Trigger | Schedule: `0 8,20 * * *` (08:00 + 20:00 UTC daily) + `workflow_dispatch` |
| Runner | `ubuntu-latest` |
| Python | 3.12 |

**What it does (in order):**
1. Checks out the repo with full history
2. Installs `requirements_live_trackers.txt`
3. Runs all 10 pipeline stages (Stages 2–8 have `continue-on-error: true`)
4. Copies `output/*.json` and `tracker_config.json` to `docs/data/`
5. Commits and pushes output to `main` with retry logic (up to 5 attempts, merge-on-conflict with `--strategy-option=ours`)

**Required secrets:** `BRAVE_API_KEY`, `ANTHROPIC_API_KEY` (and optionally `LLAMA_SCOUT_KEY`)

---

### `deploy.yml` — Validate on Push

| Setting | Value |
|---------|-------|
| Trigger | Every push to `main` + `workflow_dispatch` |
| Runner | `ubuntu-latest` |

**What it does:**
- Validates `tracker_config.json` parses as valid JSON
- Compiles all pipeline `.py` scripts (`py_compile`) — catches syntax errors before they reach production
- Confirms `docs/index.html` exists
- Scans for hardcoded secrets matching `(api_key|secret|password|token)\s*=\s*["'][A-Za-z0-9+/=]{16,}`

**No secrets required.** Pure validation only.

---

### `sync_context_index.yml` — Knowledge Base Sync

| Setting | Value |
|---------|-------|
| Trigger | Schedule: `0 6 * * *` (06:00 UTC — 2 hours before main pipeline) + `workflow_dispatch` |
| Runner | `ubuntu-latest` |

**What it does:** Runs `scripts/sync_context_index.py`, which fetches the git tree of `Leerrooy95/The_Regulated_Friction_Project` via the GitHub API and downloads only files in `_AI_CONTEXT_INDEX/` that have changed (compares blob SHA-1 hashes). Never overwrites pipeline-generated files (`12_ENTITY_GRAPH.md`, `PROFILE_README.md`). Commits and pushes changes with retry logic.

**No secrets required** (reads a public repository).

---

## Configuration — `tracker_config.json`

The single source of truth for the entire pipeline. Uses semantic versioning (`v2.6` as of 2026-03-23). Contains:

- **Leverage nodes** — nodes with their Brave search queries, classification rules, and per-node `search_recency_filter` (`day` for kinetic nodes like `iran`/`israel`; `week` for legal/financial nodes)
- **Signal definitions** — active intelligence signals with search queries
- **Tracked entities** — named entities for breaking news scanning
- **Entity disambiguation** — canonical name mappings to prevent model confusion (e.g. "Oracle Corporation" is tracked for financial leverage, not Oracle NetSuite)
- **Standing entity corrections** — entries that `fact_checker.py` injects into the Claude verification prompt to correct stale or inaccurate entity references. Fully data-driven: add entries to `standing_entity_corrections` in the config and the fact checker applies them automatically

---

## Output Files

| File | Produced By | What It Contains |
|------|-------------|-----------------|
| `output/node_status.json` | Stage 1 | Live status of all nodes + classification |
| `output/extracted_entities.json` | Stage 2 | Entities, relationships, cross-node links |
| `output/convergence_report.json` | Stage 3 | Convergence windows, friction↔compliance pairs |
| `output/daily_intelligence.json` | Stage 4 | Signal status, breaking news, daily summary |
| `output/live_verification.json` | Stage 4 | Prediction verification results |
| `output/fact_check.json` | Stage 5 | Claude fact-verification results + corrections |
| `output/rhetoric_reality.json` | Stage 6 | Three-column gap analysis per development |
| `output/entity_kb_context.json` | Stage 6.5 | Structured JSON for AI agent |
| `output/pipeline_validation.json` | Stage 7 | Cross-stage consistency check results |
| `output/chart_data.json` | Stage 7.5 | Historical data aggregated for charts |
| `output/history/tracker_*.json` | Stage 1 | Timestamped run archive |
| `output/history/intel_*.json` | Stage 4 | Timestamped intelligence archive |
| `_AI_CONTEXT_INDEX/12_ENTITY_GRAPH.md` | Stage 6.5 | Entity graph for AI chatbot KB |
| `_AI_CONTEXT_INDEX/13_RHETORIC_VS_REALITY.md` | Stage 6.5 | Rhetoric vs. reality for AI chatbot KB |

All `output/*.json` files and `tracker_config.json` are automatically copied to `docs/data/` and published to GitHub Pages after every pipeline run.

---

## Dashboard

A static single-page HTML dashboard (`docs/index.html`) is served from GitHub Pages at your custom domain (or `<username>.github.io/<repo>`). It reads the `docs/data/*.json` files directly in the browser — no backend required.

**Tabs:**
1. **Node Status** — Live status cards with classification badges, confidence levels, entity tags
2. **Intelligence** — Daily summary, signal status, breaking news, priority watchlist
3. **Convergence** — Multi-node convergence windows, friction/compliance pairs
4. **Predictions** — Pending and resolved prediction tracking (when configured)
5. **Entities** — Structured entity/relationship extraction
6. **Entity Graph** — Interactive PyVis HTML graph
7. **Charts** — Historical trend charts from aggregated run history
8. **Rhetoric vs. Reality** — Three-column gap analysis table
9. **History** — Timeline of pipeline runs and convergence events

---

## How to Set It Up (Start to Finish)

Setup is designed to take **under 15 minutes**. There are no servers, no databases, and no deployment commands — just secrets and a repo.

### Step 1 — Create the Repository

Extract the archive and push it to a new GitHub repository:

```bash
tar -xf leroyswebdevelopment.tar.xz
cd leroyswebdevelopment
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

---

### Step 2 — Add Secrets

In GitHub: **Settings → Secrets and variables → Actions → New repository secret**

| Secret Name | Where to Get It | Required? |
|-------------|-----------------|-----------|
| `BRAVE_API_KEY` | [brave.com/search/api](https://brave.com/search/api/) → API | ✅ Required |
| `ANTHROPIC_API_KEY` | [console.anthropic.com](https://console.anthropic.com) | ✅ Required (Stages 1, 4, 5, + 6) |
| `LLAMA_SCOUT_KEY` | GitHub → Settings → Developer settings → Tokens (Classic) | Optional — falls back to GLiNER2-only |

That is the entire secrets configuration. The pipeline will work with only `BRAVE_API_KEY` and `ANTHROPIC_API_KEY`.

---

### Step 3 — Enable GitHub Pages

In GitHub: **Settings → Pages**
- Source: **Deploy from a branch**
- Branch: `main` / `docs`

If you have a custom domain, set it here and update `docs/CNAME` with your domain name.

---

### Step 4 — Trigger the First Run

Go to **Actions → Run Tracker Pipeline → Run workflow**.

Watch the stages complete in the Actions tab. After the run:
- `output/` files appear in the repo
- `docs/data/` is populated
- The dashboard at your GitHub Pages URL shows live data

---

### Step 5 — Verify Automatic Scheduling

The pipeline now runs automatically at **08:00 and 20:00 UTC every day**. The `sync_context_index.yml` workflow runs at **06:00 UTC** each day to pull updated knowledge base files from the parent project.

No further action required.

---

### Optional: Local Development

```bash
# Install dependencies
pip install -r requirements_live_trackers.txt

# Copy .env.example and fill in your keys
cp .env.example .env
chmod 600 .env

# Full pipeline run
chmod +x run_pipeline.sh
./run_pipeline.sh

# Dry run (no API calls, just preview)
./run_pipeline.sh --dry-run

# Individual stages
python3 node_tracker.py              # Stage 1
python3 entity_extractor.py          # Stage 2
python3 convergence_detector.py      # Stage 3
python3 daily_intelligence.py        # Stage 4
python3 fact_checker.py              # Stage 5
python3 rhetoric_reality.py          # Stage 6
python3 build_kb_context.py          # Stage 6.5
python3 validate_pipeline.py         # Stage 7
python3 build_chart_data.py          # Stage 7.5
python3 graph_builder.py             # Stage 8

# Preview the dashboard locally
cd docs && python -m http.server 8080
# Open http://localhost:8080
```

---

## API Budget

The pipeline includes daily budget trackers to prevent runaway costs:

| Stage | API | Calls/Day | Budget Tracker |
|-------|-----|-----------|----------------|
| Stage 1 | Brave Search + Anthropic Claude | ~7 Brave searches (one per node) + ~7 Claude calls | `.api_budget.json` (50/day limit) |
| Stage 2 | Llama Scout | 1 (batch) | N/A — single call |
| Stage 4 | Brave Search + Anthropic Claude | ~8+ Brave searches (one per signal) + Claude news analysis | `.api_budget_intel.json` (100/day limit) |
| Stage 5 | Brave Search + Anthropic Claude Sonnet | Up to 30 verification searches + 1–2 Claude calls | N/A |
| Stage 6 | Anthropic Claude Sonnet | 1 | N/A |

Stages 3, 6.5, 7, 7.5, and 8 make **zero API calls** — local computation only.

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| Stage 1 fails with `BRAVE_API_KEY not set` | Add `BRAVE_API_KEY` to repo secrets |
| Stage 5/6 fails with `ANTHROPIC_API_KEY not set` | Add `ANTHROPIC_API_KEY` to repo secrets |
| Stage 2 extraction warns and skips | Normal if `LLAMA_SCOUT_KEY` is not set — falls back to GLiNER2 |
| Push fails with merge conflict | The retry loop (5 attempts) handles this automatically |
| Dashboard shows old data | Check that `docs/data/` was updated in the last commit |
| `validate_pipeline.py` reports warnings | Non-blocking — check `output/pipeline_validation.json` for details |
| No output committed | Run had no new data, or all stages errored — check Actions logs |

---

## Security Checklist

- ✅ All API keys stored as GitHub Secrets — never in code
- ✅ `.env` is gitignored
- ✅ CI scans for hardcoded secrets on every push (`deploy.yml`)
- ✅ Dashboard is 100% static HTML — no server-side code, no attack surface
- ✅ `sync_context_index.yml` reads only a public repository — no token required

---

## Summary

The Live Trackers pipeline is a **zero-infrastructure, self-healing, fully automated intelligence system**. You add three API keys as GitHub Secrets, push the code, enable GitHub Pages, and click **Run workflow** once. After that, it runs itself — twice a day, every day — querying AI APIs, analyzing patterns, verifying facts, and publishing a live dashboard to your domain. The entire setup takes less than 15 minutes.

| What you manage | What the pipeline manages |
|-----------------|--------------------------|
| 3 API secrets | All scheduling |
| GitHub Pages settings | All API calls |
| Your custom domain (optional) | All data storage |
| | All dashboard publishing |
| | All fact verification |
| | All knowledge base updates |

*Built by Austin Smith. First line of Python: October 2025.*
