# Copilot Accountability Brainstorm

> Brainstorming documents for building an AI-powered legal case analysis agent — a tool designed to help hold the system accountable by giving under-resourced defendants access to the same quality of case analysis that money can buy.

**Created:** April 2, 2026  
**Brainstorming partners:** Austin Smith + GitHub Copilot

---

## Documents

| File | What It Covers |
|------|----------------|
| [BRAINSTORM.md](./BRAINSTORM.md) | The vision, problem statement, why this is buildable now, feature roadmap (MVP → V3), test case strategy, and how this differs from existing tools |
| [ARCHITECTURE.md](./ARCHITECTURE.md) | Technical architecture — file structure, database schema, authentication flow, chat engine context injection, document processing pipeline, chat modes, security architecture, API cost estimates, deployment options |
| [LEGAL_AND_ETHICS.md](./LEGAL_AND_ETHICS.md) | Attorney-client privilege considerations (US v. Heppner), ABA Formal Opinion 512, state-specific rules, bias/hallucination mitigation, ethical use guidelines, legal developments to monitor |
| [REUSE_MAP.md](./REUSE_MAP.md) | Exact mapping of existing code (OSINT_ChatBot, Bill_Translator, Live_Trackers pipeline) to new components — what to copy, what to adapt, what to build new |

## Read Order

1. **BRAINSTORM.md** — Start here. Understand the problem, the vision, and why the existing tools make this feasible.
2. **ARCHITECTURE.md** — Technical deep dive. How it all fits together.
3. **REUSE_MAP.md** — The practical "what code do we reuse" guide.
4. **LEGAL_AND_ETHICS.md** — Critical guardrails. Read before any development begins.

## Key Insight

~70% of the needed functionality already exists across Austin's projects (OSINT_ChatBot, Bill_Translator, Live_Trackers pipeline). The new work is primarily:
- Persistent per-case memory (SQLite + SQLCipher)
- Document ingestion (pdfplumber)
- Context window management (the memory manager)

The estimated MVP can be built in 2–3 focused development sessions.
