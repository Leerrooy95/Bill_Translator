# Accountability Agent — Reuse Map

> Maps existing code from Austin's projects to the components needed for the Accountability Agent.  
> This is the practical "what do we copy and adapt" guide.

---

## Overview

The goal is to reuse as much proven code as possible. Austin's existing projects cover ~70% of what the Accountability Agent needs. This document maps each new component to its source.

---

## Component-by-Component Mapping

### 1. Flask Application Shell

**Source:** `OSINT_ChatBot` (Flask app structure)

**What to reuse:**
- Flask app factory pattern
- Route structure (`/login`, `/chat`, `/logout`)
- Template structure (`base.html`, `login.html`)
- Static file organization
- `render.yaml` for optional deployment

**What to adapt:**
- Add case management routes (`/cases`, `/cases/<id>`, `/cases/<id>/upload`)
- Replace multi-user BYOK login with single-user master password
- Add document upload routes

---

### 2. Authentication

**Source:** `OSINT_ChatBot` (login flow, session management)

**What to reuse:**
- Flask-Login session management
- Rate limiting configuration (Flask-Limiter)
- Session cookie settings (HttpOnly, Secure, SameSite)
- 2-hour session expiry logic

**What to adapt:**
- Replace "enter your API key" login with master password login
- Add bcrypt password hashing (the OSINT_ChatBot validates API key format; this validates a password hash)
- Add SQLCipher key derivation from master password

---

### 3. BYOK API Key Management

**Source:** `OSINT_ChatBot` (`knowledge_base.py` + session handling)

**What to reuse directly (minimal changes):**
- API key format validation
- Encrypted session cookie storage
- Key injection into Anthropic API calls
- Key cleared on session expiry

**What to adapt:**
- Add a second BYOK field for Brave Search API key (OSINT_ChatBot only takes Anthropic key)
- Keys are entered after master password login (two-step: authenticate, then provide API keys)

---

### 4. Chat Engine (Claude Conversation)

**Source:** `OSINT_ChatBot` (chat route + knowledge base injection)

**What to reuse:**
- Anthropic Messages API integration
- System prompt construction
- Knowledge base text injection into system prompt
- Message history management
- Response streaming (if implemented)

**What to adapt:**
- Replace static `_AI_CONTEXT_INDEX/` knowledge base with dynamic per-case context
- Build system prompt from case metadata + document summaries + facts + timeline + entities + recent conversation
- Add mode switching (analysis, research, drafting, plain_language, fact_check)
- Add context window management (summarize older messages when context gets too long)

---

### 5. Legal Research (Web Search + Analysis)

**Source:** `Live_Trackers` pipeline — `daily_intelligence.py` + `fact_checker.py`

**What to reuse:**
- Brave Search API integration (query construction, result parsing)
- Claude analysis of search results (search results → structured analysis)
- The three-pass intelligence protocol pattern (adapted: search → analyze → verify)

**What to adapt:**
- Replace geopolitical queries with legal queries (statutes, case law, precedents)
- Replace node-tracking context with case-specific context
- Add citation extraction from search results (case names, statute numbers)

---

### 6. Fact Verification

**Source:** `Live_Trackers` pipeline — `fact_checker.py`

**What to reuse:**
- Brave Search web evidence collection
- Claude cross-reference verification pattern
- Confidence rating system (HIGH/MEDIUM/LOW)
- In-place correction logic

**What to adapt:**
- Replace geopolitical claim verification with legal claim verification
- Add specific checks for: statute number validity, case citation validity, legal standard accuracy
- Integrate with the chat engine (verify claims in AI responses before displaying)

---

### 7. Entity Extraction

**Source:** `Live_Trackers` pipeline — `entity_extractor.py`

**What to reuse:**
- GLiNER2 integration (local, zero-cost)
- Entity type classification
- Disambiguation logic from `tracker_config.json`

**What to adapt:**
- Replace geopolitical entity types with legal entity types:
  - `person` → defendant, plaintiff, witness, officer, judge, attorney
  - `organization` → court, agency, department, law firm
  - `jurisdiction` → state, county, circuit
  - `date` → arrest date, hearing date, filing deadline
  - `statute` → Ark. Code §, federal statute
  - `location` → crime scene, jail, courthouse
- Store entities in the per-case database instead of JSON files

---

### 8. Plain Language Translation

**Source:** `Bill_Translator` — `translator_agent.py`

**What to reuse:**
- Textstat Flesch-Kincaid scoring
- Claude translation prompt (dense legal text → 8th-grade readability)
- Meaning drift detection (extract legal terms before, compare after)
- Auto re-iteration until target grade reached

**What to adapt:**
- Integrate as a chat mode rather than a standalone app
- When user switches to "plain language" mode, all responses pass through the readability engine
- Apply to: AI case explanations, legal document summaries, court procedure explanations

---

### 9. Security Stack

**Source:** `OSINT_ChatBot` (full security implementation)

**What to reuse directly:**
- CSRF protection (Flask-WTF)
- Rate limiting (Flask-Limiter)
- DOMPurify sanitization (frontend)
- Security headers (CSP, HSTS, X-Frame-Options, X-Content-Type-Options)
- HttpOnly/SameSite/Secure cookies

**What to add:**
- SQLCipher database encryption
- File upload validation (extension whitelist, size limits, content-type verification)
- Uploaded file sandboxing (stored with hashed filenames, not user-provided names)

---

### 10. Dashboard / Visualization (V3)

**Source:** `Live_Trackers` — `docs/index.html` + `graph_builder.py` + `build_chart_data.py`

**What to reuse (in V3):**
- Chart.js integration for case timeline visualization
- NetworkX + PyVis for entity relationship graphs per case
- The tabbed dashboard layout pattern

**What to adapt:**
- Replace geopolitical nodes with case entities
- Replace intelligence tabs with case tabs (Documents, Chat, Timeline, Entities, Graph)
- Scale down from nine tabs to five

---

## New Components (Not From Existing Code)

These are the pieces that need to be built from scratch:

| Component | What It Does | Complexity |
|-----------|-------------|-----------|
| **Database layer** (`models.py`) | SQLAlchemy models + SQLCipher encryption | Medium — standard SQLAlchemy + SQLCipher wrapper |
| **Case manager** (`case_manager.py`) | CRUD operations for cases | Low — straightforward Flask routes |
| **Document processor** (`document_processor.py`) | PDF/text ingestion + text extraction | Medium — pdfplumber integration + storage logic |
| **Memory manager** (`memory_manager.py`) | Per-case context assembly for system prompt | Medium — the core innovation; manages what goes into Claude's context window |
| **Master password auth** (`auth.py`) | bcrypt hashing + SQLCipher key derivation | Low — simpler than multi-user auth |

---

## Dependencies to Add

| Package | Purpose | Already Used? |
|---------|---------|---------------|
| `flask` | Web framework | ✅ OSINT_ChatBot, Bill_Translator |
| `anthropic` | Claude API | ✅ OSINT_ChatBot, Bill_Translator, pipeline |
| `requests` | Brave Search API calls | ✅ Pipeline |
| `gliner` | Entity extraction (local) | ✅ Pipeline |
| `textstat` | Flesch-Kincaid scoring | ✅ Bill_Translator |
| `pdfplumber` | PDF text extraction | 🆕 New |
| `sqlalchemy` | ORM for SQLite | 🆕 New |
| `sqlcipher3` | Encrypted SQLite | 🆕 New |
| `bcrypt` | Password hashing | 🆕 New |
| `flask-login` | Session management | 🆕 New (OSINT_ChatBot may use custom sessions) |
| `flask-wtf` | CSRF protection | ✅ OSINT_ChatBot |
| `flask-limiter` | Rate limiting | ✅ OSINT_ChatBot |
| `bleach` | Backend HTML sanitization | 🆕 New |

---

## File-Level Copy Map

This table shows exactly which files to copy and how to adapt them:

| New File | Copy From | Adaptation Needed |
|----------|-----------|-------------------|
| `app.py` | OSINT_ChatBot main app | Add case routes, document routes, mode switching |
| `auth.py` | OSINT_ChatBot login logic | Replace API key validation with master password + bcrypt |
| `chat_engine.py` | OSINT_ChatBot chat route + knowledge_base.py | Replace static KB with dynamic case context injection |
| `legal_researcher.py` | Live_Trackers daily_intelligence.py | Replace geopolitical queries with legal queries |
| `fact_checker.py` | Live_Trackers fact_checker.py | Replace geopolitical verification with legal verification |
| `entity_extractor.py` | Live_Trackers entity_extractor.py | Replace entity types, store to DB instead of JSON |
| `plain_language.py` | Bill_Translator translator_agent.py | Extract readability engine, integrate as chat mode |
| `templates/login.html` | OSINT_ChatBot login template | Simplify to master password field |
| `templates/base.html` | OSINT_ChatBot base template | Update branding, add case navigation |
| `static/styles.css` | OSINT_ChatBot styles | Adapt for case management UI |
| `config.py` | OSINT_ChatBot config | Add database path, upload settings |
| `.gitignore` | Live_Trackers .gitignore | Add database files, uploads directory |
| `requirements.txt` | Merge from all three projects | Add pdfplumber, sqlalchemy, sqlcipher3, bcrypt |

---

## Summary

```
Existing code reuse:  ~70%
New code to write:    ~30%
New dependencies:      5 packages (pdfplumber, sqlalchemy, sqlcipher3, bcrypt, bleach)
Estimated MVP effort:  2–3 focused development sessions
```

The heaviest new work is the **memory manager** — the component that decides what case context to inject into Claude's system prompt on each message. Everything else is either a direct reuse or a straightforward adaptation of existing, production-proven code.
