# Accountability Agent — Legal & Ethical Considerations

> Critical guardrails for building and using an AI-powered legal case analysis tool.  
> This document should be reviewed before any development begins.

---

## Disclaimer

**This tool is not a lawyer.** It is a research and analysis assistant. It does not provide legal advice, and its output should never be treated as a substitute for a licensed attorney's judgment. The tool is designed to augment human analysis — not replace it.

---

## 1. Attorney-Client Privilege

### The Risk

In **US v. Heppner (February 2026)**, a federal court ruled that attorney-client privilege does not attach to communications shared with a generic, consumer-grade AI tool. If a lawyer or client inputs privileged information into a tool that lacks proper confidentiality safeguards, the privilege may be waived.

### How This Tool Mitigates the Risk

| Safeguard | Implementation |
|-----------|---------------|
| **Single-user access** | Master password — only Austin can access the tool |
| **No cloud storage of case data** | Database is local (SQLite), encrypted at rest (SQLCipher AES-256) |
| **BYOK model** | API keys are session-only, never stored on disk |
| **No training on case data** | Anthropic's API does not use API inputs for model training (per their data policy as of 2026) |
| **No third-party data sharing** | The tool does not send case data to any service other than the AI provider (Anthropic) for analysis |
| **Encryption in transit** | All API calls use HTTPS/TLS |
| **Session expiry** | 2-hour session timeout; all in-memory data cleared |

### Recommendation

- **Verify Anthropic's data policy** before each major use. As of April 2026, Anthropic states that API inputs are not used for training. This should be confirmed periodically.
- **If working with an attorney**, ensure the attorney is aware of and consents to the tool's use. The attorney's supervision helps preserve privilege under the Heppner standard.
- **Keep records** of what data was shared with the AI and when, in case privilege is ever challenged.

---

## 2. ABA Ethics Rules (Formal Opinion 512)

The American Bar Association's **Formal Opinion 512 (July 2024)** — the most recent comprehensive guidance — establishes that existing Model Rules of Professional Conduct govern AI use. Key requirements:

### Competence (Rule 1.1)
- The person using the tool must understand its limitations
- AI output must be reviewed and verified before being relied upon
- The tool includes built-in fact verification (Brave Search + Claude cross-reference) to reduce hallucination risk

### Confidentiality (Rule 1.6)
- Client information must be protected from unauthorized disclosure
- The tool's architecture (local database, encryption, single-user, BYOK) is designed to meet this standard
- No case data should be shared with anyone who does not have a legitimate need to know

### Supervision (Rules 5.1, 5.3)
- If an attorney is involved, they must supervise the tool's use
- All AI output should be reviewed by a human before being used in any legal proceeding

### Communication (Rule 1.4)
- If used in support of a case where a client is involved, the client should be informed that AI tools are being used in their case analysis
- Transparency about AI involvement is increasingly required across states

---

## 3. State-Specific Rules (Arkansas Focus)

### Arkansas

- Arkansas follows the ABA Model Rules with minimal modification
- The Arkansas Supreme Court has not issued AI-specific guidance as of April 2026
- **Recommendation:** Follow ABA Formal Opinion 512 as the baseline, and monitor for Arkansas-specific guidance

### Other States (If Cases Cross Jurisdictions)

| State | Key AI Rule | Implication |
|-------|------------|-------------|
| **California** | Attorneys must understand LLM basics | Ensure competence with the tool |
| **Florida** | Disclosure required if AI affects billing | Disclose if applicable |
| **Texas** | Human oversight required to prevent hallucinations | Built-in fact verification addresses this |
| **New York** | Focus on confidentiality in digital tools | Local-first architecture addresses this |

---

## 4. What This Tool Is and Is Not

### This Tool IS:
- A research assistant that can quickly search law, analyze documents, and organize case information
- A writing aid that can draft motions, briefs, and summaries for human review
- A fact-checking system that verifies claims against live web sources
- A plain-language translator that makes legal documents understandable
- A case organizer that tracks timelines, entities, and key facts

### This Tool IS NOT:
- A lawyer or legal advisor
- A replacement for professional legal counsel
- A tool that should be used without human oversight
- A system whose output should be filed with a court without attorney review
- A tool that guarantees legal outcomes

---

## 5. Data Handling Best Practices

### What Data Goes Into the Tool
- Case documents (police reports, court filings, witness statements)
- Case notes and analysis
- Conversation history with the AI

### What Data Leaves the Tool
- Text sent to Anthropic's Claude API for analysis (covered by HTTPS + Anthropic's data policy)
- Search queries sent to Brave Search API for legal research
- **Nothing else.** No data is sent to any other third party.

### Data Retention
- All case data is stored in the encrypted SQLite database
- Cases can be archived or permanently deleted
- When a case is deleted, all associated documents, conversations, facts, entities, and timeline events are cascade-deleted from the database
- The database file can be securely wiped with standard file shredding tools if needed

### Backup
- The database is a single file — back it up by copying it to an encrypted external drive
- The backup is also encrypted (SQLCipher) — it cannot be read without the master password

---

## 6. Bias and Hallucination Mitigation

### The Problem
AI models can:
- Fabricate case law citations ("hallucinate" non-existent cases)
- Reflect biases present in their training data
- Make confident-sounding statements that are wrong

### Built-In Mitigations

| Risk | Mitigation |
|------|-----------|
| **Hallucinated citations** | Fact verification via Brave Search + Claude cross-reference (same pattern as pipeline's fact_checker.py) |
| **Fabricated case law** | Research mode cross-references all cited cases against Brave Search results |
| **Bias** | System prompt explicitly instructs Claude to flag uncertainty, present multiple perspectives, and avoid assumptions |
| **Overconfidence** | System prompt requires confidence ratings (HIGH/MEDIUM/LOW) on all analytical claims |
| **Outdated information** | Brave Search integration provides live web results for current statutes and case law |

### Human-in-the-Loop Requirement
- **Every output should be reviewed by a human** before being acted upon
- The tool should be treated as a brilliant but fallible research assistant — not an oracle
- Critical claims (statute numbers, case citations, legal standards) should always be independently verified

---

## 7. Ethical Use Guidelines

1. **Use this tool to help people, not exploit them.** The purpose is accountability — helping those who cannot afford adequate representation get a better analysis of their cases.

2. **Never misrepresent AI output as attorney work product** unless an attorney has reviewed and adopted it.

3. **Be transparent** about the tool's involvement in any case work.

4. **Protect case data** with the same care you would protect physical case files.

5. **Report bugs and errors** — if the tool produces incorrect legal analysis, document it and improve the system.

6. **Do not use this tool for cases where you have a conflict of interest.**

7. **Do not use this tool to harass, intimidate, or harm anyone.**

---

## 8. Relevant Legal Developments to Monitor

| Development | Why It Matters | Status (April 2026) |
|-------------|---------------|---------------------|
| **US v. Heppner ruling** | Sets precedent on AI tools and privilege | Federal ruling issued Feb 2026 |
| **ABA Formal Opinion 512** | Core ethics framework for AI in legal practice | Issued July 2024, still current |
| **Arkansas AI guidance** | Could impose state-specific requirements | Not yet issued — monitor |
| **Anthropic data policy** | Governs whether API inputs are used for training | Currently states no training on API inputs |
| **GENIUS Act / stablecoin regulation** | Could affect crypto-related cases | Pending in Congress |
| **State public defender reform bills** | Could change the landscape for indigent defense | AR SB 67 allocated $35.6M |

---

## Sources

- [US v. Heppner: The ChatGPT Privilege Ruling](https://gc.ai/legal-ai-privilege-heppner-ruling) — February 2026
- [ABA Formal Opinion 512](https://www.arias-us.org/wp-content/uploads/2026/01/ABA-Ethics-Guidance-AI-July-2025I.pdf) — July 2024
- [AI Legal Compliance for U.S. Law Firms (2026 Guide)](https://www.clio.com/blog/ai-legal-compliance/) — Clio
- [State Bar Rules on AI Use](https://www.spellbook.legal/learn/state-bar-rules-ai-use) — Spellbook Legal
- [Beyond the Ban: Why Your Law Firm Needs a Realistic AI Policy in 2026](https://www.ncbar.org/2026/01/13/beyond-the-ban-why-your-law-firm-needs-a-realistic-ai-policy-in-2026/) — NC Bar Association
- [Arkansas Advisory Committee: Right to Counsel in Arkansas](https://www.usccr.gov/files/2025-04/report-brief_right-to-counsel-in-arkansas-2024.pdf) — U.S. Commission on Civil Rights
- [Privilege Considerations When Using Generative AI in Legal Practice](https://www.frantzward.com/privilege-considerations-when-using-generative-artificial-intelligence-in-legal-practice/) — Frantz Ward LLP
