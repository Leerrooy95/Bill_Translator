# Accountability Agent — Brainstorm

> **Working title:** The Accountability Agent  
> **Author:** GitHub Copilot (brainstorming partner for Austin Smith)  
> **Date:** April 2, 2026  

---

## The Problem

Arkansas public defenders carry 200+ felony cases at a time — more than triple the recommended maximum of 63. The U.S. Commission on Civil Rights called the state's indigent defense system "unethical and unconstitutional." Despite a recent $35.6M budget increase, starting salaries remain uncompetitive, turnover is chronic, and defendants sit in jail for months without meaningful representation.

This is not unique to Arkansas. Across the country, the poor are swept into the criminal justice system and cannot get out, while those with resources buy their way to better outcomes every time. Pretrial detention alone costs taxpayers billions and ruins lives before a verdict is ever reached.

**The gap:** A single overworked public defender cannot research every statute, read every police report, cross-reference case law, analyze body camera footage transcripts, and prepare a personalized defense — all while juggling hundreds of other cases. But an AI agent, purpose-built and properly guided by a human, can do most of that research in minutes.

---

## The Vision

A **secure, BYOK, persistent-memory legal case analysis agent** — a Flask web app that Austin controls with a master password and Flask secret key. It can:

1. **Ingest case files** — PDFs, .txt, .md, images of documents
2. **Build persistent memory per case** — every fact, every document, every conversation thread is stored and recalled across sessions
3. **Research law** — search for relevant statutes, case law, precedents using web search (Brave Search API)
4. **Analyze evidence** — identify contradictions in police reports, flag timeline inconsistencies, spot missing evidence
5. **Draft legal documents** — motions, briefs, cross-examination questions, defense strategy outlines
6. **Track case status** — deadlines, hearings, filings, next steps
7. **Explain everything at an 8th-grade reading level** — so defendants and their families actually understand what's happening (reusing the Bill Translator's readability engine)

**Who uses it:** Austin. One user, one master password. The reason: attorney-client privilege considerations (see LEGAL_AND_ETHICS.md) and the sensitivity of case data require absolute control over access. This is not a SaaS product — it is a personal tool for case advocacy work.

---

## Why This Is Buildable Right Now

Austin's existing pipeline and projects provide nearly every component needed. Here is how the pieces map:

| Need | Existing Tool | Status |
|------|---------------|--------|
| Flask web app framework | OSINT_ChatBot, Bill_Translator | ✅ Production-proven |
| BYOK API key management | OSINT_ChatBot (encrypted session cookies) | ✅ Production-proven |
| AI analysis engine | Anthropic Claude (Sonnet/Opus) via Messages API | ✅ Production-proven |
| Web search for real-time info | Brave Search API integration | ✅ Production-proven |
| Document readability translation | Bill_Translator (Textstat + Flesch-Kincaid) | ✅ 31 tests passing |
| Fact verification | fact_checker.py (Brave + Claude cross-reference) | ✅ Production-proven |
| Entity extraction | GLiNER2 (local, zero-cost) + entity_extractor.py | ✅ Production-proven |
| Knowledge base injection | knowledge_base.py (system prompt injection) | ✅ Production-proven |
| Security headers, CSRF, rate limiting | OSINT_ChatBot security stack | ✅ Production-proven |
| Persistent memory across sessions | **NEW** — needs database layer | 🔧 To build |
| PDF/document ingestion | **NEW** — needs pdfplumber/PyPDF2 integration | 🔧 To build |
| Case-specific knowledge base | **NEW** — needs per-case scoped memory | 🔧 To build |
| Master password auth (single-user) | **NEW** — simpler than BYOK multi-user | 🔧 To build |

**Bottom line:** ~70% of the functionality already exists across Austin's projects. The new work is (1) persistent memory, (2) document ingestion, and (3) case-scoped sessions.

---

## Core Architecture (High-Level)

```
┌─────────────────────────────────────────────────────────┐
│                     Flask Web App                        │
│                                                         │
│  ┌──────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │  Auth     │  │  Case Manager│  │  Chat Interface  │  │
│  │  (master  │  │  (create,    │  │  (per-case       │  │
│  │  password)│  │  switch,     │  │  conversation    │  │
│  │          │  │  archive)    │  │  with Claude)    │  │
│  └──────────┘  └──────────────┘  └──────────────────┘  │
│                                                         │
│  ┌──────────────────────────────────────────────────┐   │
│  │              Document Processor                   │   │
│  │  PDF → text (pdfplumber)                         │   │
│  │  .md/.txt → direct ingest                        │   │
│  │  Image → OCR (optional, Tesseract)               │   │
│  │  → Entity extraction (GLiNER2)                   │   │
│  │  → Store in case memory                          │   │
│  └──────────────────────────────────────────────────┘   │
│                                                         │
│  ┌──────────────────────────────────────────────────┐   │
│  │              Analysis Engine                      │   │
│  │  Brave Search → legal research                   │   │
│  │  Claude → case analysis, drafting, strategy      │   │
│  │  Fact Checker → verify claims                    │   │
│  │  Bill Translator → plain-language explanations   │   │
│  └──────────────────────────────────────────────────┘   │
│                                                         │
│  ┌──────────────────────────────────────────────────┐   │
│  │              Persistent Memory (SQLite)           │   │
│  │  Cases table → case metadata                     │   │
│  │  Documents table → ingested files + extracted    │   │
│  │  Conversations table → full chat history         │   │
│  │  Facts table → extracted key facts per case      │   │
│  │  Timeline table → case events, deadlines         │   │
│  └──────────────────────────────────────────────────┘   │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## Key Design Decisions

### 1. SQLite for Persistence (Not Postgres, Not Cloud)

**Why:** This is a single-user tool on a controlled machine. SQLite is:
- Zero-configuration (no database server)
- File-based (easy to back up — just copy the `.db` file)
- Encrypted at rest with `sqlcipher` (AES-256 encryption using the master password as the key)
- Portable (move the database with the app)

If this ever scales to multi-user, the SQLite schema migrates cleanly to Postgres.

### 2. Master Password + Flask Secret Key (Not OAuth, Not Multi-User)

**Why:** This tool handles case data that could be legally sensitive. A single master password:
- Eliminates the attack surface of user management
- Keeps everything under Austin's direct control
- Avoids third-party auth dependencies
- The master password also derives the SQLCipher encryption key for the database

### 3. BYOK for AI API Keys (Same Pattern as OSINT_ChatBot)

**Why:** The AI provider (Anthropic) never sees the master password or case structure. Austin provides the API key in the browser. The key is stored in an encrypted session cookie — never on disk. If the session expires, the key is gone.

### 4. Case-Scoped Memory (Not Global)

**Why:** Each case is a self-contained knowledge unit. When Austin opens "Case: Smith v. State of Arkansas," the agent:
- Loads only that case's documents, facts, timeline, and conversation history into context
- Does not cross-contaminate with other cases
- Can be archived or deleted independently

### 5. Local-First, Deploy-Optional

**Why:** The app should run on Austin's local machine for maximum security. Deployment to Render or DigitalOcean is optional — the architecture supports it, but the default is `flask run` on localhost.

---

## Proposed Feature Set (MVP → V2 → V3)

### MVP (v0.1) — The Core Loop

- [ ] Master password login
- [ ] Create / select / archive a case
- [ ] Upload PDF, .txt, .md files to a case
- [ ] Chat with Claude about the case (case memory injected into system prompt)
- [ ] Persistent conversation history (survives browser close / server restart)
- [ ] Brave Search integration for legal research within chat
- [ ] Basic case timeline tracking (manual entries)

### V2 — Intelligence Features

- [ ] Automatic entity extraction from uploaded documents (GLiNER2)
- [ ] Contradiction detection across documents (e.g., police report says X, witness statement says Y)
- [ ] Statute and case law lookup (Brave Search + Claude analysis)
- [ ] Legal document drafting mode (motions, briefs, cross-examination questions)
- [ ] Plain-language explanation mode (Bill Translator engine)
- [ ] Fact verification on all AI-generated claims (fact_checker.py pattern)

### V3 — Advanced

- [ ] Timeline visualization for case events (Chart.js, reusing dashboard pattern)
- [ ] Entity relationship graph per case (NetworkX + PyVis, reusing graph_builder.py)
- [ ] OCR for scanned documents and handwritten notes (Tesseract)
- [ ] Export case summary as PDF/Markdown
- [ ] Deadline alerts and calendar integration
- [ ] Multi-case cross-reference (find patterns across cases)

---

## The Test Case

Austin mentioned using a test case to develop and tune the agent. Here's a recommended approach:

1. **Select a real or realistic case** — ideally a closed/resolved Arkansas DOC case where the outcome is known, so the agent's analysis can be benchmarked against reality
2. **Ingest the case files** — police reports, court filings, witness statements, sentencing documents
3. **Run the agent through a full analysis cycle:**
   - Ask it to summarize the case
   - Ask it to identify weaknesses in the prosecution's argument
   - Ask it to find relevant case law
   - Ask it to draft a motion (e.g., motion to suppress, motion for discovery)
   - Ask it to explain the situation in plain language
4. **Compare the agent's output to what actually happened** — did it catch things the defense missed? Did it identify the right statutes?
5. **Iterate on prompts, memory structure, and document processing** based on results

---

## What Makes This Different From Existing Tools

| Feature | Existing Tools (Grounds, LexDecipher, etc.) | This Tool |
|---------|----------------------------------------------|-----------|
| Cost | $50–500/month subscription | BYOK — pay only API costs (~$5–10/month) |
| Data control | Cloud-hosted, provider has access | Local-first, encrypted, single-user |
| Customization | Fixed features | Full source access, modify anything |
| Integration with OSINT pipeline | None | Direct reuse of Brave Search, Claude, GLiNER2, fact-checker |
| Plain-language translation | None | Built-in Bill Translator engine |
| Open source | Mostly proprietary | Fully open (your code, your data) |

---

## Immediate Next Steps

1. **Read ARCHITECTURE.md** — detailed technical architecture and file structure
2. **Read REUSE_MAP.md** — exact mapping of existing code to new components
3. **Read LEGAL_AND_ETHICS.md** — critical legal and ethical guardrails
4. **Decide on a test case** — Austin picks a case to develop against
5. **Start building the MVP** — estimated 2–3 focused sessions to get the core loop working

---

## Sources Consulted (April 2026)

- [AI and Technology Help Bridge Access to Justice](https://www.probonoinst.org/2026/02/06/ai-and-technology-help-bridge-access-to-justice/) — Pro Bono Institute
- [Closing the Justice Gap: How AI Tools Can Make Legal Help Affordable](https://casesolutions.ai/posts/law)
- [Access to Justice 2.0: How AI-powered software can bridge the gap](https://www.americanbar.org/groups/journal/articles/2025/access-to-justice-how-ai-powered-software-can-bridge-the-gap/) — ABA
- [2026 AI for Indigent Defense: Sword and Shield](https://www.cpda.org/2026-ai-for-indigent-defense--sword-and-shield) — CPDA
- [New report reveals crisis in Arkansas public defender system](https://katv.com/news/local/new-report-reveals-crisis-in-arkansas-public-defender-system-robert-steinbuch-ualr-bowen-us-commission-on-civil-rights-arkansas-advisory-committee-right-to-counsel-constitutional-rights-caseload-defendant-public-defender-pay-lack-of-funding-felony-cases)
- [Arkansas Advisory Committee: Right to Counsel in Arkansas](https://www.usccr.gov/files/2025-04/report-brief_right-to-counsel-in-arkansas-2024.pdf) — U.S. Commission on Civil Rights
- [Winnable criminal justice reforms in 2026](https://www.prisonpolicy.org/reports/winnable2026.html) — Prison Policy Initiative
- [ABA Formal Opinion 512 — Ethics Guidance on AI](https://www.arias-us.org/wp-content/uploads/2026/01/ABA-Ethics-Guidance-AI-July-2025I.pdf)
- [US v. Heppner: The ChatGPT Privilege Ruling](https://gc.ai/legal-ai-privilege-heppner-ruling) — Feb 2026
- [AI Legal Compliance for U.S. Law Firms (2026 Guide)](https://www.clio.com/blog/ai-legal-compliance/) — Clio
- [State Bar Rules on AI Use](https://www.spellbook.legal/learn/state-bar-rules-ai-use) — Spellbook Legal
- [Why BYOK Is the Strategic Choice for AI in 2026](https://geekflare.com/guides/byok-ai-business-strategy/) — Geekflare
- [How to Build AI Agents with Persistent Memory (2026)](https://www.retaindb.com/blogs/persistent-memory-ai-agents)
- [Legal Case Analyzer (open source)](https://github.com/oleggazman/legal-case-analyzer)
- [Existing AI Tools for Criminal Defense](https://www.law.berkeley.edu/research/criminal-law-and-justice-center/our-work/ai-for-public-defenders/existing-ai-tools/) — UC Berkeley Law
