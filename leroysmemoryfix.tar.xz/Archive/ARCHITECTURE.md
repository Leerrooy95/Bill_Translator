# Accountability Agent — Technical Architecture

> Detailed technical design for the Accountability Agent.  
> Read **BRAINSTORM.md** first for the vision and high-level overview.

---

## Tech Stack

| Layer | Technology | Reason |
|-------|-----------|--------|
| **Web framework** | Flask (Python) | Battle-tested in OSINT_ChatBot and Bill_Translator |
| **AI backbone** | Anthropic Claude (Messages API) | Already integrated, BYOK pattern proven |
| **Web search** | Brave Search API | Already integrated in Live_Trackers pipeline |
| **Entity extraction** | GLiNER2 (local, zero-cost) | Already integrated in entity_extractor.py |
| **PDF processing** | pdfplumber | Best Python PDF text extraction library (2026) |
| **OCR (v3)** | Tesseract via pytesseract | Open-source, well-supported |
| **Readability** | Textstat (Flesch-Kincaid) | Already integrated in Bill_Translator |
| **Database** | SQLite + SQLCipher | Zero-config, encrypted at rest, single-file |
| **Session management** | Flask-Login + itsdangerous | Proven pattern from OSINT_ChatBot |
| **Frontend** | HTML/CSS/JS (Jinja2 templates) | Consistent with existing apps; no JS framework overhead |
| **Deployment** | Local (default) / Render (optional) | Local-first for security; Render for remote access |

---

## Project File Structure

```
Accountability_Agent/
├── app.py                          # Flask application entry point
├── auth.py                         # Master password authentication
├── config.py                       # App configuration (Flask secret, DB path, etc.)
├── models.py                       # SQLAlchemy/SQLCipher database models
├── case_manager.py                 # Case CRUD operations
├── document_processor.py           # PDF/txt/md ingestion + text extraction
├── chat_engine.py                  # Claude conversation engine with case context injection
├── legal_researcher.py             # Brave Search + Claude legal research
├── fact_checker.py                 # Claim verification (adapted from pipeline)
├── entity_extractor.py             # GLiNER2 entity extraction (adapted from pipeline)
├── plain_language.py               # Bill Translator readability engine (adapted)
├── memory_manager.py               # Per-case persistent memory (facts, timeline, context)
├── requirements.txt                # Python dependencies
├── .env.example                    # Template for environment variables
├── .gitignore                      # Standard ignores + database files
├── templates/
│   ├── login.html                  # Master password login page
│   ├── dashboard.html              # Case list / overview
│   ├── case.html                   # Single case view (chat + documents + timeline)
│   ├── upload.html                 # Document upload interface
│   └── base.html                   # Shared layout template
├── static/
│   ├── styles.css                  # App styling
│   └── app.js                      # Frontend interactivity
├── data/                           # SQLite database lives here (gitignored)
│   └── .gitkeep
├── uploads/                        # Uploaded files (gitignored, encrypted filenames)
│   └── .gitkeep
└── tests/
    ├── test_auth.py                # Authentication tests
    ├── test_document_processor.py  # Document ingestion tests
    ├── test_chat_engine.py         # Chat context injection tests
    ├── test_memory_manager.py      # Persistent memory tests
    └── test_fact_checker.py        # Fact verification tests
```

---

## Database Schema

SQLite with SQLCipher encryption (AES-256). The master password derives the encryption key via PBKDF2.

```sql
-- Cases
CREATE TABLE cases (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,               -- e.g., "Smith v. State of Arkansas"
    status      TEXT DEFAULT 'active',       -- active, archived, closed
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes       TEXT                          -- free-form case notes
);

-- Documents (ingested files)
CREATE TABLE documents (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id     INTEGER NOT NULL REFERENCES cases(id),
    filename    TEXT NOT NULL,               -- original filename
    file_type   TEXT NOT NULL,               -- pdf, txt, md, image
    raw_text    TEXT,                         -- extracted full text
    summary     TEXT,                         -- AI-generated summary
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Extracted entities from documents
CREATE TABLE entities (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id     INTEGER NOT NULL REFERENCES cases(id),
    document_id INTEGER REFERENCES documents(id),
    entity_type TEXT NOT NULL,               -- person, organization, date, location, statute, etc.
    entity_name TEXT NOT NULL,
    context     TEXT,                         -- surrounding text where entity was found
    confidence  REAL                          -- extraction confidence score
);

-- Conversation history
CREATE TABLE conversations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id     INTEGER NOT NULL REFERENCES cases(id),
    role        TEXT NOT NULL,               -- 'user' or 'assistant'
    content     TEXT NOT NULL,
    mode        TEXT DEFAULT 'analysis',     -- analysis, drafting, research, plain_language
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Key facts (distilled from documents and conversations)
CREATE TABLE facts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id     INTEGER NOT NULL REFERENCES cases(id),
    fact_text   TEXT NOT NULL,
    source      TEXT,                         -- which document or conversation produced this
    verified    BOOLEAN DEFAULT FALSE,        -- has fact been verified by fact_checker?
    confidence  TEXT,                         -- HIGH, MEDIUM, LOW
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Case timeline
CREATE TABLE timeline (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id     INTEGER NOT NULL REFERENCES cases(id),
    event_date  DATE,
    event_type  TEXT,                         -- arrest, hearing, filing, deadline, incident
    description TEXT NOT NULL,
    source      TEXT,                         -- which document or manual entry
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## Authentication Flow

```
User visits /login
    │
    ▼
Enters master password
    │
    ▼
Server hashes password with bcrypt, compares to stored hash
    │
    ├── Match → Create Flask session (HttpOnly, Secure, SameSite=Strict cookie)
    │           Derive SQLCipher key from password (PBKDF2)
    │           Open encrypted database
    │           Redirect to /dashboard
    │
    └── No match → Rate-limited retry (10 attempts/min, then lockout)
```

**First-run setup:** On first launch, if no password hash exists, the app prompts for initial password creation. The password is never stored — only the bcrypt hash and the PBKDF2-derived database key.

---

## Chat Engine — Context Injection Strategy

The chat engine follows the same pattern as the OSINT_ChatBot but with **case-scoped context injection**:

```
System prompt:
┌──────────────────────────────────────────────┐
│ You are a legal case analysis assistant.      │
│ You have access to the following case files:  │
│                                               │
│ [CASE METADATA]                               │
│ Name: Smith v. State of Arkansas              │
│ Status: Active                                │
│ Created: 2026-03-15                           │
│                                               │
│ [DOCUMENTS — summaries + key excerpts]        │
│ 1. police_report.pdf — Summary: ...           │
│ 2. witness_statement.txt — Summary: ...       │
│ 3. charging_document.pdf — Summary: ...       │
│                                               │
│ [EXTRACTED FACTS]                             │
│ - Defendant was at location X at time Y       │
│ - Officer Z wrote report 3 hours after event  │
│ - Witness A contradicts Officer Z on ...      │
│                                               │
│ [TIMELINE]                                    │
│ 2026-01-15: Arrest                            │
│ 2026-01-16: Initial appearance                │
│ 2026-02-01: Preliminary hearing               │
│ 2026-03-01: Filing deadline for motions       │
│                                               │
│ [ENTITIES]                                    │
│ Persons: John Smith, Officer Jones, ...       │
│ Statutes: Ark. Code § 5-10-103, ...          │
│ Locations: 123 Main St, Little Rock, AR       │
│                                               │
│ [CONVERSATION HISTORY — last N messages]      │
│ (injected for continuity)                     │
│                                               │
│ [INSTRUCTIONS]                                │
│ - Always cite specific documents when making  │
│   claims about the case                       │
│ - Flag contradictions between documents       │
│ - When unsure, say so explicitly              │
│ - Never fabricate case law or statutes        │
│ - When asked for plain language, target 8th   │
│   grade reading level                         │
└──────────────────────────────────────────────┘
```

**Context window management:** Claude's context window is large but not infinite. The memory_manager.py handles:
1. **Always include:** Case metadata, timeline, extracted facts, entity list
2. **Include summaries:** Document summaries (not full text) unless user asks about a specific document
3. **Include recent conversation:** Last 20 messages
4. **On demand:** Full document text injected when user says "look at [document name]"
5. **Overflow strategy:** If context exceeds limits, prioritize recent conversation + facts + timeline, summarize older conversation history

---

## Document Processing Pipeline

```
User uploads file
    │
    ▼
document_processor.py determines file type
    │
    ├── PDF → pdfplumber.extract_text() → raw_text
    ├── .txt → direct read → raw_text
    ├── .md → direct read → raw_text
    └── Image → pytesseract.image_to_string() → raw_text (v3)
    │
    ▼
Store raw_text in documents table
    │
    ▼
entity_extractor.py (GLiNER2) extracts entities
    │
    ▼
Store entities in entities table
    │
    ▼
Claude generates document summary
    │
    ▼
Store summary in documents table
    │
    ▼
Claude extracts key facts from document
    │
    ▼
Store facts in facts table
    │
    ▼
Claude extracts timeline events from document
    │
    ▼
Store events in timeline table
```

---

## Legal Research Flow

When the user asks a legal question within the chat:

```
User: "What are the grounds for a motion to suppress in Arkansas?"
    │
    ▼
legal_researcher.py detects research intent
    │
    ▼
Brave Search API: queries for Arkansas motion to suppress case law, statutes
    │
    ▼
Claude analyzes search results in context of the current case
    │
    ▼
Response includes:
    - Relevant Arkansas statutes (Ark. Code §)
    - Recent case law with citations
    - How it applies to THIS specific case
    - Suggested next steps
    │
    ▼
fact_checker.py verifies statute numbers and case citations
    │
    ▼
Verified response delivered to user
```

---

## Chat Modes

The chat interface supports multiple modes (switchable via dropdown or command):

| Mode | Behavior | Use Case |
|------|----------|----------|
| **Analysis** | Deep case analysis, contradiction detection, strategy | Default mode — working through case details |
| **Research** | Brave Search + Claude legal research | Finding statutes, case law, precedents |
| **Drafting** | Legal document generation | Motions, briefs, letters, cross-exam questions |
| **Plain Language** | 8th-grade readability output (Bill Translator engine) | Explaining situation to defendant/family |
| **Fact Check** | Verify specific claims against web sources | Checking AI-generated claims or case assertions |

---

## Security Architecture

| Layer | Implementation | Source |
|-------|---------------|--------|
| **Authentication** | bcrypt-hashed master password, rate-limited | New (simpler than OSINT_ChatBot multi-user) |
| **Database encryption** | SQLCipher (AES-256), key derived from master password | New |
| **Session security** | HttpOnly, Secure, SameSite=Strict cookies, 2-hour expiry | OSINT_ChatBot pattern |
| **BYOK** | API key in encrypted session cookie, never on disk | OSINT_ChatBot pattern |
| **CSRF protection** | Flask-WTF CSRF tokens | OSINT_ChatBot pattern |
| **Rate limiting** | Flask-Limiter (10 login/min, 30 chat/min) | OSINT_ChatBot pattern |
| **Input sanitization** | DOMPurify (frontend), bleach (backend) | OSINT_ChatBot pattern |
| **Security headers** | CSP, HSTS, X-Frame-Options, X-Content-Type-Options | OSINT_ChatBot pattern |
| **File upload safety** | Extension whitelist (.pdf, .txt, .md), file size limit, sandboxed storage | New |
| **Secrets scanning** | CI scans for hardcoded secrets (deploy.yml pattern) | Live_Trackers pattern |

---

## Environment Variables

```bash
# Required
FLASK_SECRET_KEY=<random-64-char-hex>    # Auto-generated on first run if not set

# Provided by user in browser (BYOK)
# ANTHROPIC_API_KEY — entered in UI, stored in encrypted session cookie
# BRAVE_API_KEY — entered in UI, stored in encrypted session cookie

# Optional
DATABASE_PATH=data/accountability.db     # Default location
UPLOAD_DIR=uploads/                       # Default location
MAX_UPLOAD_SIZE_MB=50                     # Per-file upload limit
SESSION_LIFETIME_HOURS=2                  # Session expiry
```

---

## Deployment Options

### Option A: Local (Recommended for MVP)

```bash
pip install -r requirements.txt
python app.py
# Opens at http://127.0.0.1:5000
```

All data stays on Austin's machine. Database file is encrypted. No internet exposure.

### Option B: Render (Remote Access)

Same pattern as OSINT_ChatBot and Bill_Translator:
- `render.yaml` blueprint
- `FLASK_SECRET_KEY` as Render environment variable
- Render's free tier supports the traffic level
- Database persists on Render's disk (encrypted via SQLCipher)

### Option C: DigitalOcean (Already Has Infrastructure)

Austin already has DigitalOcean infrastructure for scrapers and the Gradient AI chatbot. The Accountability Agent could run alongside them.

---

## API Cost Estimate

| Action | API | Estimated Cost |
|--------|-----|----------------|
| Chat message (analysis mode) | Anthropic Claude Sonnet | ~$0.003–0.01 per message |
| Document summary generation | Anthropic Claude Sonnet | ~$0.01–0.03 per document |
| Legal research query | Brave Search (free tier: 2000/month) + Claude | ~$0.01 per query |
| Fact verification | Brave Search + Claude | ~$0.01 per check |
| Entity extraction | GLiNER2 (local) | $0.00 |

**Estimated monthly cost for active use:** $5–15/month (similar to current pipeline costs)

---

## Testing Strategy

Adapting the Bill_Translator's 31-test pattern:

| Test Category | What It Covers |
|---------------|----------------|
| **Auth tests** | Password hashing, login flow, rate limiting, session expiry |
| **Document tests** | PDF extraction, text ingestion, entity extraction, summary generation |
| **Memory tests** | Case creation, fact storage, timeline storage, context retrieval |
| **Chat tests** | Context injection, mode switching, conversation persistence |
| **Security tests** | CSRF, XSS prevention, file upload validation, SQL injection prevention |
| **Integration tests** | Full flow: login → create case → upload doc → chat → verify facts |
