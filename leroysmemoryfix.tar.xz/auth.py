"""
auth.py — Master Password Authentication
==========================================
Single-user authentication with bcrypt password hashing.
The master password also derives the SQLCipher encryption key via PBKDF2.
"""

import hashlib
import logging
import os
from pathlib import Path

import bcrypt

from config import Config

logger = logging.getLogger(__name__)


def _hash_file() -> Path:
    """Return the path to the password hash file."""
    return Path(Config.PASSWORD_HASH_FILE)


def is_first_run() -> bool:
    """Check if this is the first run (no password hash exists)."""
    return not _hash_file().exists()


def create_password(password: str) -> None:
    """Hash and store the master password on first run."""
    if len(password) < 8:
        raise ValueError("Password must be at least 8 characters.")
    hashed = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(rounds=12))
    _hash_file().parent.mkdir(parents=True, exist_ok=True)
    _hash_file().write_bytes(hashed)
    logger.info("Master password created and stored.")


def verify_password(password: str) -> bool:
    """Verify the master password against the stored hash."""
    if is_first_run():
        return False
    stored_hash = _hash_file().read_bytes()
    return bcrypt.checkpw(password.encode("utf-8"), stored_hash)


def derive_db_key(password: str) -> str:
    """
    Derive a SQLCipher encryption key from the master password using PBKDF2.
    Returns a hex string suitable for PRAGMA key.
    """
    # Use a fixed salt derived from the Flask secret key for deterministic key derivation
    salt = hashlib.sha256(Config.SECRET_KEY.encode("utf-8")).digest()[:16]
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations=600_000)
    return dk.hex()
