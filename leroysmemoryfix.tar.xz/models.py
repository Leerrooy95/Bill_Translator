"""
models.py — Database Models for Accountability Agent
=====================================================
SQLite database layer with optional SQLCipher encryption.
Uses Python's built-in sqlite3 module for maximum compatibility.
SQLCipher encryption is applied when the sqlcipher3 package is available.
"""

import sqlite3
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# Try to import sqlcipher3 for encrypted database support
try:
    from sqlcipher3 import dbapi2 as sqlcipher

    _HAS_SQLCIPHER = True
    logger.info("SQLCipher available — database encryption enabled.")
except ImportError:
    _HAS_SQLCIPHER = False
    logger.warning(
        "sqlcipher3 not installed — database will NOT be encrypted. "
        "Install with: pip install sqlcipher3-binary"
    )

# ─── SCHEMA ──────────────────────────────────────────────────────────────────

_SCHEMA = """
CREATE TABLE IF NOT EXISTS cases (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    status      TEXT DEFAULT 'active',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes       TEXT
);

CREATE TABLE IF NOT EXISTS documents (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id     INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    filename    TEXT NOT NULL,
    file_type   TEXT NOT NULL,
    raw_text    TEXT,
    summary     TEXT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS entities (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id     INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    document_id INTEGER REFERENCES documents(id) ON DELETE CASCADE,
    entity_type TEXT NOT NULL,
    entity_name TEXT NOT NULL,
    context     TEXT,
    confidence  REAL
);

CREATE TABLE IF NOT EXISTS conversations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id     INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    role        TEXT NOT NULL,
    content     TEXT NOT NULL,
    mode        TEXT DEFAULT 'analysis',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS facts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id     INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    fact_text   TEXT NOT NULL,
    source      TEXT,
    verified    BOOLEAN DEFAULT 0,
    confidence  TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS timeline (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id     INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    event_date  DATE,
    event_type  TEXT,
    description TEXT NOT NULL,
    source      TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""


def get_connection(db_path: str, encryption_key: str | None = None) -> sqlite3.Connection:
    """
    Open a database connection. If sqlcipher3 is available and an encryption_key
    is provided, the database is opened with AES-256 encryption.
    """
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)

    if _HAS_SQLCIPHER and encryption_key:
        conn = sqlcipher.connect(db_path)
        conn.execute(f"PRAGMA key = '{encryption_key}'")
        logger.info("Opened encrypted database at %s", db_path)
    else:
        conn = sqlite3.connect(db_path)
        logger.info("Opened unencrypted database at %s", db_path)

    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    """Create all tables if they don't exist.

    Performs a cheap existence check first so that repeated calls (e.g. once
    per request via before_request) are effectively free after the first run.
    """
    row = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='cases'"
    ).fetchone()
    if row is not None:
        return  # Schema already in place — nothing to do.
    conn.executescript(_SCHEMA)
    conn.commit()
    logger.info("Database schema initialized.")


# ─── CASE OPERATIONS ─────────────────────────────────────────────────────────

def create_case(conn: sqlite3.Connection, name: str, notes: str = "") -> int:
    """Create a new case and return its ID."""
    cur = conn.execute(
        "INSERT INTO cases (name, notes) VALUES (?, ?)", (name, notes)
    )
    conn.commit()
    return cur.lastrowid


def get_case(conn: sqlite3.Connection, case_id: int) -> dict | None:
    """Get a single case by ID."""
    row = conn.execute("SELECT * FROM cases WHERE id = ?", (case_id,)).fetchone()
    return dict(row) if row else None


def list_cases(conn: sqlite3.Connection, status: str = "active") -> list[dict]:
    """List cases filtered by status."""
    rows = conn.execute(
        "SELECT * FROM cases WHERE status = ? ORDER BY updated_at DESC", (status,)
    ).fetchall()
    return [dict(r) for r in rows]


def update_case(conn: sqlite3.Connection, case_id: int, **kwargs) -> None:
    """Update case fields."""
    allowed = {"name", "status", "notes"}
    fields = {k: v for k, v in kwargs.items() if k in allowed}
    if not fields:
        return
    sets = ", ".join(f"{k} = ?" for k in fields)
    vals = list(fields.values()) + [case_id]
    conn.execute(
        f"UPDATE cases SET {sets}, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        vals,
    )
    conn.commit()


def delete_case(conn: sqlite3.Connection, case_id: int) -> None:
    """Permanently delete a case and all associated data (cascade)."""
    conn.execute("DELETE FROM cases WHERE id = ?", (case_id,))
    conn.commit()


# ─── DOCUMENT OPERATIONS ─────────────────────────────────────────────────────

def add_document(
    conn: sqlite3.Connection,
    case_id: int,
    filename: str,
    file_type: str,
    raw_text: str = "",
    summary: str = "",
) -> int:
    """Add a document record and return its ID."""
    cur = conn.execute(
        "INSERT INTO documents (case_id, filename, file_type, raw_text, summary) "
        "VALUES (?, ?, ?, ?, ?)",
        (case_id, filename, file_type, raw_text, summary),
    )
    conn.commit()
    return cur.lastrowid


def get_documents(conn: sqlite3.Connection, case_id: int) -> list[dict]:
    """Get all documents for a case."""
    rows = conn.execute(
        "SELECT * FROM documents WHERE case_id = ? ORDER BY uploaded_at DESC",
        (case_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def get_document(conn: sqlite3.Connection, doc_id: int) -> dict | None:
    """Get a single document by ID."""
    row = conn.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
    return dict(row) if row else None


def update_document(conn: sqlite3.Connection, doc_id: int, **kwargs) -> None:
    """Update document fields (summary, raw_text)."""
    allowed = {"raw_text", "summary"}
    fields = {k: v for k, v in kwargs.items() if k in allowed}
    if not fields:
        return
    sets = ", ".join(f"{k} = ?" for k in fields)
    vals = list(fields.values()) + [doc_id]
    conn.execute(f"UPDATE documents SET {sets} WHERE id = ?", vals)
    conn.commit()


# ─── ENTITY OPERATIONS ───────────────────────────────────────────────────────

def add_entity(
    conn: sqlite3.Connection,
    case_id: int,
    entity_type: str,
    entity_name: str,
    document_id: int | None = None,
    context: str = "",
    confidence: float = 1.0,
) -> int:
    """Add an extracted entity."""
    cur = conn.execute(
        "INSERT INTO entities (case_id, document_id, entity_type, entity_name, context, confidence) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (case_id, document_id, entity_type, entity_name, context, confidence),
    )
    conn.commit()
    return cur.lastrowid


def get_entities(conn: sqlite3.Connection, case_id: int) -> list[dict]:
    """Get all entities for a case."""
    rows = conn.execute(
        "SELECT * FROM entities WHERE case_id = ? ORDER BY entity_type, entity_name",
        (case_id,),
    ).fetchall()
    return [dict(r) for r in rows]


# ─── CONVERSATION OPERATIONS ─────────────────────────────────────────────────

def add_conversation(
    conn: sqlite3.Connection,
    case_id: int,
    role: str,
    content: str,
    mode: str = "analysis",
) -> int:
    """Add a conversation message."""
    cur = conn.execute(
        "INSERT INTO conversations (case_id, role, content, mode) VALUES (?, ?, ?, ?)",
        (case_id, role, content, mode),
    )
    conn.commit()
    return cur.lastrowid


def get_conversations(
    conn: sqlite3.Connection, case_id: int, limit: int = 50
) -> list[dict]:
    """Get recent conversations for a case."""
    rows = conn.execute(
        "SELECT * FROM conversations WHERE case_id = ? ORDER BY id DESC LIMIT ?",
        (case_id, limit),
    ).fetchall()
    return [dict(r) for r in reversed(rows)]


# ─── FACT OPERATIONS ─────────────────────────────────────────────────────────

def add_fact(
    conn: sqlite3.Connection,
    case_id: int,
    fact_text: str,
    source: str = "",
    confidence: str = "MEDIUM",
) -> int:
    """Add a key fact."""
    cur = conn.execute(
        "INSERT INTO facts (case_id, fact_text, source, confidence) VALUES (?, ?, ?, ?)",
        (case_id, fact_text, source, confidence),
    )
    conn.commit()
    return cur.lastrowid


def get_facts(conn: sqlite3.Connection, case_id: int) -> list[dict]:
    """Get all facts for a case."""
    rows = conn.execute(
        "SELECT * FROM facts WHERE case_id = ? ORDER BY created_at", (case_id,)
    ).fetchall()
    return [dict(r) for r in rows]


def update_fact(conn: sqlite3.Connection, fact_id: int, verified: bool, confidence: str) -> None:
    """Mark a fact as verified/unverified."""
    conn.execute(
        "UPDATE facts SET verified = ?, confidence = ? WHERE id = ?",
        (int(verified), confidence, fact_id),
    )
    conn.commit()


# ─── TIMELINE OPERATIONS ─────────────────────────────────────────────────────

def add_timeline_event(
    conn: sqlite3.Connection,
    case_id: int,
    description: str,
    event_date: str = "",
    event_type: str = "",
    source: str = "",
) -> int:
    """Add a timeline event."""
    cur = conn.execute(
        "INSERT INTO timeline (case_id, event_date, event_type, description, source) "
        "VALUES (?, ?, ?, ?, ?)",
        (case_id, event_date or None, event_type, description, source),
    )
    conn.commit()
    return cur.lastrowid


def get_timeline(conn: sqlite3.Connection, case_id: int) -> list[dict]:
    """Get timeline events for a case, ordered by event date."""
    rows = conn.execute(
        "SELECT * FROM timeline WHERE case_id = ? ORDER BY event_date, created_at",
        (case_id,),
    ).fetchall()
    return [dict(r) for r in rows]
