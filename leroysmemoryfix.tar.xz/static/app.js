/**
 * app.js — Accountability Agent Frontend Interactivity
 * =====================================================
 * Handles tab switching, chat AJAX, markdown rendering,
 * copy-to-clipboard, file upload UX, and keyboard shortcuts.
 */

document.addEventListener('DOMContentLoaded', () => {
    initTabs();
    initChat();
    initExistingMessages();
    initUpload();
});

/* ── Tab Switching ─────────────────────────────────────────────────────────── */

function initTabs() {
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Deactivate all tabs and content
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

            // Activate clicked tab
            tab.classList.add('active');
            const targetId = 'tab-' + tab.dataset.tab;
            const target = document.getElementById(targetId);
            if (target) target.classList.add('active');
        });
    });
}

/* ── Existing Messages — Markdown Render + Copy Wiring ────────────────────── */

function initExistingMessages() {
    document.querySelectorAll('.message').forEach(msg => {
        const isAssistant = msg.classList.contains('message-assistant');
        const contentEl = msg.querySelector('.message-content');
        const copyBtn = msg.querySelector('.copy-btn');
        if (!contentEl) return;

        // Capture raw text BEFORE we modify innerHTML
        const rawText = contentEl.textContent;

        if (isAssistant) {
            contentEl.innerHTML = renderMarkdown(rawText);
            contentEl.classList.add('rendered');
        }

        if (copyBtn) {
            copyBtn.addEventListener('click', () => copyToClipboard(rawText, copyBtn));
        }
    });
}

/* ── Chat Interface ────────────────────────────────────────────────────────── */

function initChat() {
    const chatForm = document.getElementById('chat-form');
    if (!chatForm) return;

    chatForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const messageInput = document.getElementById('chat-message');
        const modeSelect = document.getElementById('chat-mode');
        const sendBtn = document.getElementById('send-btn');
        const message = messageInput.value.trim();

        if (!message) return;

        const mode = modeSelect ? modeSelect.value : 'analysis';

        // Disable input while sending
        sendBtn.disabled = true;
        sendBtn.textContent = 'Sending...';
        messageInput.disabled = true;

        // Add user message to chat, clear input, show typing indicator
        appendMessage('user', message, mode);
        messageInput.value = '';
        const typingId = showTypingIndicator();

        try {
            // Determine endpoint based on mode
            let endpoint = `/cases/${CASE_ID}/chat`;
            let body = new FormData();
            body.append('message', message);
            body.append('mode', mode);

            if (mode === 'research') {
                endpoint = `/cases/${CASE_ID}/research`;
                body = new FormData();
                body.append('question', message);
            } else if (mode === 'fact_check') {
                endpoint = `/cases/${CASE_ID}/fact-check`;
                body = new FormData();
                body.append('claim', message);
            }

            const response = await fetch(endpoint, { method: 'POST', body });
            const data = await response.json();

            removeTypingIndicator(typingId);

            if (data.error) {
                appendMessage('assistant', `Error: ${data.error}`, mode);
            } else if (data.response) {
                appendMessage('assistant', data.response, mode);
            } else if (data.explanation) {
                // Fact check result
                const factResult = `**Verdict:** ${data.verdict}\n**Confidence:** ${data.confidence}\n\n${data.explanation}`;
                appendMessage('assistant', factResult, mode);
            }
        } catch (err) {
            removeTypingIndicator(typingId);
            appendMessage('assistant', `Error: ${err.message}`, mode);
        } finally {
            sendBtn.disabled = false;
            sendBtn.textContent = 'Send';
            messageInput.disabled = false;
            messageInput.focus();
        }
    });

    // Ctrl+Enter / Cmd+Enter to send
    const messageInput = document.getElementById('chat-message');
    if (messageInput) {
        messageInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                chatForm.dispatchEvent(new Event('submit'));
            }
        });
    }
}

function showTypingIndicator() {
    const container = document.getElementById('chat-messages');
    if (!container) return null;
    const id = 'typing-' + Date.now();
    const div = document.createElement('div');
    div.id = id;
    div.className = 'message message-assistant typing-indicator';
    div.innerHTML = '<div class="message-content"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></div>';
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
    return id;
}

function removeTypingIndicator(id) {
    if (!id) return;
    const el = document.getElementById(id);
    if (el) el.remove();
}

function appendMessage(role, content, mode) {
    const container = document.getElementById('chat-messages');
    if (!container) return;

    // Remove empty state placeholder
    const empty = container.querySelector('.empty-chat');
    if (empty) empty.remove();

    const div = document.createElement('div');
    div.className = `message message-${role === 'user' ? 'user' : 'assistant'}`;

    const header = document.createElement('div');
    header.className = 'message-header';

    const strong = document.createElement('strong');
    strong.textContent = role === 'user' ? 'You' : 'Agent';
    header.appendChild(strong);

    const badge = document.createElement('span');
    badge.className = 'mode-badge';
    badge.textContent = mode;
    header.appendChild(badge);

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-btn';
    copyBtn.title = 'Copy to clipboard';
    copyBtn.textContent = '📋';
    copyBtn.addEventListener('click', () => copyToClipboard(content, copyBtn));
    header.appendChild(copyBtn);

    const msgContent = document.createElement('div');
    msgContent.className = 'message-content';

    if (role !== 'user') {
        msgContent.innerHTML = renderMarkdown(content);
        msgContent.classList.add('rendered');
    } else {
        msgContent.textContent = content;
    }

    div.appendChild(header);
    div.appendChild(msgContent);
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

/* ── Copy to Clipboard ─────────────────────────────────────────────────────── */

function copyToClipboard(text, btn) {
    const original = btn.textContent;
    const onSuccess = () => {
        btn.textContent = '✓';
        btn.classList.add('copied');
        setTimeout(() => {
            btn.textContent = original;
            btn.classList.remove('copied');
        }, 2000);
    };

    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(onSuccess).catch(() => fallbackCopy(text, onSuccess));
    } else {
        fallbackCopy(text, onSuccess);
    }
}

function fallbackCopy(text, callback) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;pointer-events:none;';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    try { document.execCommand('copy'); callback(); } catch (_) {}
    document.body.removeChild(ta);
}

/* ── Markdown Renderer ─────────────────────────────────────────────────────── */

/**
 * Escape special HTML characters to prevent XSS.
 * Used for plain-text insertions (e.g. copy-to-clipboard raw text).
 */
function escHtml(str) {
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

// Configure marked (v17) once at startup:
// - gfm: GitHub Flavored Markdown — enables tables, task lists, strikethrough
// - breaks: false — require a blank line for a new paragraph (matches Claude output style)
// - pedantic: false — CommonMark-style parsing
(function _configureMarked() {
    if (typeof marked === 'undefined') return;
    marked.use({ gfm: true, breaks: false, pedantic: false });
}());

/**
 * Convert markdown text to safe HTML using marked.js (v17).
 * Tables are wrapped in a scrollable container for responsive layout.
 * Falls back to preformatted escaped text if marked is unavailable.
 */
function renderMarkdown(raw) {
    if (typeof marked !== 'undefined') {
        let html = marked.parse(raw);
        // Wrap tables in a scrollable container (matches existing .table-wrapper CSS)
        html = html.replace(/<table>/g, '<div class="table-wrapper"><table>')
                   .replace(/<\/table>/g, '</table></div>');
        return html;
    }
    // Fallback: display as preformatted escaped text
    return `<pre>${escHtml(raw)}</pre>`;
}

/* ── File Upload ───────────────────────────────────────────────────────────── */

function initUpload() {
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const fileNameDisplay = document.getElementById('file-name');

    if (!dropZone || !fileInput) return;

    // Show filename when selected
    fileInput.addEventListener('change', () => {
        if (fileInput.files.length > 0 && fileNameDisplay) {
            fileNameDisplay.textContent = `Selected: ${fileInput.files[0].name}`;
        }
    });

    // Drag and drop styling
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        if (e.dataTransfer.files.length > 0) {
            fileInput.files = e.dataTransfer.files;
            if (fileNameDisplay) {
                fileNameDisplay.textContent = `Selected: ${e.dataTransfer.files[0].name}`;
            }
        }
    });
}
