"""
chat_engine.py — Claude Conversation Engine with Case Context Injection
=========================================================================
Handles conversations with Anthropic Claude, injecting per-case context
into the system prompt. Supports multiple chat modes.
"""

import logging
import time

import anthropic

import models
import memory_manager

logger = logging.getLogger(__name__)

_MAX_RETRIES = 3
_BASE_BACKOFF = 2


def chat(
    conn,
    case_id: int,
    user_message: str,
    api_key: str,
    mode: str = "analysis",
    model: str = "claude-sonnet-4-6",
    max_tokens: int = 4096,
) -> str:
    """
    Send a message to Claude with full case context and return the response.

    1. Build system prompt from case memory
    2. Get recent conversation history
    3. Append user message
    4. Call Claude API
    5. Store both messages in database
    6. Return assistant response
    """
    # Build context
    system_prompt = memory_manager.build_system_prompt(conn, case_id, mode=mode)
    conversation_history = memory_manager.get_conversation_context(conn, case_id)

    # Add the new user message
    conversation_history.append({"role": "user", "content": user_message})

    # Call Claude
    client = anthropic.Anthropic(api_key=api_key)
    last_exc: Exception | None = None
    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            response = client.messages.create(
                model=model,
                max_tokens=max_tokens,
                system=system_prompt,
                messages=conversation_history,
            )
            assistant_message = response.content[0].text
            break
        except (anthropic.RateLimitError, anthropic.InternalServerError) as e:
            logger.warning(
                "Claude API attempt %d/%d failed (%s): %s",
                attempt,
                _MAX_RETRIES,
                type(e).__name__,
                e,
            )
            last_exc = e
            if attempt < _MAX_RETRIES:
                time.sleep(_BASE_BACKOFF**attempt)
        except anthropic.APIError as e:
            logger.error("Anthropic API error: %s", e)
            raise RuntimeError(f"AI service error: {e}") from e
    else:
        logger.error("Claude API failed after %d attempts.", _MAX_RETRIES)
        raise RuntimeError(f"AI service error after {_MAX_RETRIES} attempts: {last_exc}") from last_exc

    # Store in database
    models.add_conversation(conn, case_id, "user", user_message, mode)
    models.add_conversation(conn, case_id, "assistant", assistant_message, mode)

    return assistant_message


def summarize_document(conn, case_id: int, doc_id: int, api_key: str, model: str = "claude-sonnet-4-6") -> str:
    """
    Generate a summary of a document using Claude.
    Also extracts key facts and timeline events.
    """
    doc = models.get_document(conn, doc_id)
    if not doc or not doc.get("raw_text"):
        return "No text available to summarize."

    raw_text = doc["raw_text"][:50000]  # Limit to ~12.5K tokens

    prompt = (
        f"You are analyzing a legal document for case analysis purposes.\n\n"
        f"Document: {doc['filename']}\n"
        f"Type: {doc['file_type']}\n\n"
        f"DOCUMENT TEXT:\n{raw_text}\n\n"
        f"Please provide:\n"
        f"1. **SUMMARY** (2-3 paragraphs): A clear summary of this document's contents and significance.\n"
        f"2. **KEY FACTS** (bullet list): Specific factual claims that can be verified or cross-referenced.\n"
        f"3. **TIMELINE EVENTS** (list with dates if available): Any events with dates mentioned.\n"
        f"4. **ENTITIES** (categorized list): People, organizations, locations, statutes, dates mentioned.\n"
        f"5. **CONTRADICTIONS OR CONCERNS**: Anything that seems inconsistent, unusual, or worth investigating.\n\n"
        f"Format your response clearly with these section headers."
    )

    client = anthropic.Anthropic(api_key=api_key)
    last_exc: Exception | None = None
    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            response = client.messages.create(
                model=model,
                max_tokens=4096,
                messages=[{"role": "user", "content": prompt}],
            )
            summary = response.content[0].text

            # Store summary
            models.update_document(conn, doc_id, summary=summary)
            return summary

        except (anthropic.RateLimitError, anthropic.InternalServerError) as e:
            logger.warning(
                "Claude API attempt %d/%d failed (%s): %s",
                attempt,
                _MAX_RETRIES,
                type(e).__name__,
                e,
            )
            last_exc = e
            if attempt < _MAX_RETRIES:
                time.sleep(_BASE_BACKOFF**attempt)
        except anthropic.APIError as e:
            logger.error("Failed to summarize document: %s", e)
            raise RuntimeError(f"AI service error: {e}") from e

    logger.error("Claude API failed after %d attempts.", _MAX_RETRIES)
    raise RuntimeError(f"AI service error after {_MAX_RETRIES} attempts: {last_exc}") from last_exc
