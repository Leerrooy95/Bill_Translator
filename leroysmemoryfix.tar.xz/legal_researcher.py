"""
legal_researcher.py — Brave Search + Claude Legal Research
============================================================
Adapted from the Live Trackers pipeline's daily_intelligence.py.
Searches for statutes, case law, and precedents using Brave Search,
then analyzes results with Claude in the context of the current case.
"""

import json
import logging
import time

import requests

import models
import memory_manager

logger = logging.getLogger(__name__)

_BRAVE_SEARCH_URL = "https://api.search.brave.com/res/v1/web/search"
_MAX_RESULTS = 10
_MAX_RETRIES = 3
_BASE_BACKOFF = 2


def brave_search(query: str, api_key: str, count: int = _MAX_RESULTS) -> list[dict]:
    """
    Query Brave Search API and return structured results.
    Adapted from node_tracker.py's Brave Search integration.
    """
    headers = {
        "Accept": "application/json",
        "Accept-Encoding": "gzip",
        "X-Subscription-Token": api_key,
    }
    params = {"q": query, "count": count, "freshness": "py"}  # past year

    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            resp = requests.get(
                _BRAVE_SEARCH_URL, headers=headers, params=params, timeout=15
            )
            resp.raise_for_status()
            data = resp.json()

            results = []
            for item in data.get("web", {}).get("results", []):
                results.append(
                    {
                        "title": item.get("title", ""),
                        "url": item.get("url", ""),
                        "description": item.get("description", ""),
                        "age": item.get("age", ""),
                    }
                )
            return results

        except requests.RequestException as e:
            logger.warning(
                "Brave Search attempt %d/%d failed: %s", attempt, _MAX_RETRIES, e
            )
            if attempt < _MAX_RETRIES:
                time.sleep(_BASE_BACKOFF**attempt)
            else:
                logger.error("Brave Search failed after %d attempts.", _MAX_RETRIES)
                return []


def research_legal_question(
    conn,
    case_id: int,
    question: str,
    anthropic_key: str,
    brave_key: str,
    model: str = "claude-sonnet-4-6",
) -> str:
    """
    Research a legal question using Brave Search + Claude analysis.

    1. Generate targeted search queries from the question
    2. Search Brave for relevant legal sources
    3. Feed results + case context to Claude for analysis
    4. Return structured research findings
    """
    import anthropic

    # Build search queries
    case = models.get_case(conn, case_id)
    case_name = case["name"] if case else "Unknown case"

    queries = [
        question,
        f"{question} case law precedent",
        f"{question} statute",
    ]

    # Collect search results
    all_results = []
    for q in queries:
        results = brave_search(q, brave_key, count=5)
        all_results.extend(results)

    if not all_results:
        return "No search results found. Please check your Brave Search API key."

    # Deduplicate by URL
    seen_urls = set()
    unique_results = []
    for r in all_results:
        if r["url"] not in seen_urls:
            seen_urls.add(r["url"])
            unique_results.append(r)

    # Format results for Claude
    search_context = "\n\n".join(
        f"Source: {r['title']}\nURL: {r['url']}\n{r['description']}"
        for r in unique_results[:15]
    )

    # Get case context
    system_prompt = memory_manager.build_system_prompt(conn, case_id, mode="research")

    prompt = (
        f"LEGAL RESEARCH REQUEST for case: {case_name}\n\n"
        f"QUESTION: {question}\n\n"
        f"WEB SEARCH RESULTS:\n{search_context}\n\n"
        f"Based on these search results and the case context provided in the system prompt:\n"
        f"1. Identify relevant statutes with full citations\n"
        f"2. Identify relevant case law with full citations\n"
        f"3. Explain how these apply to THIS specific case\n"
        f"4. Note any conflicts between sources\n"
        f"5. Suggest concrete next steps\n"
        f"6. Rate your confidence in each finding (HIGH/MEDIUM/LOW)\n\n"
        f"IMPORTANT: Only cite sources that appear in the search results above. "
        f"Do not fabricate any citations."
    )

    client = anthropic.Anthropic(api_key=anthropic_key)
    last_exc: Exception | None = None
    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            response = client.messages.create(
                model=model,
                max_tokens=4096,
                system=system_prompt,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.content[0].text

        except (anthropic.RateLimitError, anthropic.InternalServerError) as e:
            logger.warning(
                "Claude API attempt %d/%d failed (%s): %s",
                attempt,
                _MAX_RETRIES,
                type(e).__name__,
                e,
            )
            last_exc = e
            if attempt < _MAX_RETRIES:
                time.sleep(_BASE_BACKOFF**attempt)
        except Exception as e:
            logger.error("Legal research failed: %s", e)
            raise RuntimeError(f"Research failed: {e}") from e

    logger.error("Claude API failed after %d attempts.", _MAX_RETRIES)
    raise RuntimeError(f"Research failed after {_MAX_RETRIES} attempts: {last_exc}") from last_exc
