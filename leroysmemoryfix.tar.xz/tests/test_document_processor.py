"""
test_document_processor.py — Document Processor Tests
======================================================
Tests for file validation, text extraction, and secure filename generation.
"""

import os
import tempfile

import pytest

from document_processor import (
    allowed_file,
    extract_text_from_file,
    process_upload,
    secure_filename_hash,
)


class TestAllowedFile:
    def test_pdf_allowed(self):
        assert allowed_file("report.pdf") is True

    def test_txt_allowed(self):
        assert allowed_file("notes.txt") is True

    def test_md_allowed(self):
        assert allowed_file("readme.md") is True

    def test_exe_not_allowed(self):
        assert allowed_file("virus.exe") is False

    def test_no_extension(self):
        assert allowed_file("noext") is False

    def test_empty_string(self):
        assert allowed_file("") is False

    def test_double_extension(self):
        assert allowed_file("file.pdf.exe") is False


class TestSecureFilename:
    def test_produces_hex_name(self):
        name = secure_filename_hash("report.pdf")
        assert name.endswith(".pdf")
        assert len(name) == 36  # 32 hex chars + ".pdf"

    def test_preserves_extension(self):
        assert secure_filename_hash("notes.txt").endswith(".txt")
        assert secure_filename_hash("readme.md").endswith(".md")

    def test_unique_names(self):
        name1 = secure_filename_hash("same.pdf")
        name2 = secure_filename_hash("same.pdf")
        assert name1 != name2  # Random, so different each time


class TestExtractText:
    def test_extract_text_file(self, tmp_path):
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello world\nThis is a test.")
        text = extract_text_from_file(str(test_file))
        assert "Hello world" in text
        assert "This is a test." in text

    def test_extract_markdown_file(self, tmp_path):
        test_file = tmp_path / "test.md"
        test_file.write_text("# Header\n\nParagraph text.")
        text = extract_text_from_file(str(test_file))
        assert "# Header" in text


class TestProcessUpload:
    def test_process_txt_file(self, tmp_path):
        test_file = tmp_path / "test.txt"
        test_file.write_text("Legal document content here.")
        result = process_upload(str(test_file), "test.txt")
        assert result["filename"] == "test.txt"
        assert result["file_type"] == "txt"
        assert "Legal document content" in result["raw_text"]
        assert len(result["file_hash"]) == 64

    def test_process_unsupported_type(self, tmp_path):
        test_file = tmp_path / "test.exe"
        test_file.write_text("bad")
        with pytest.raises(ValueError):
            process_upload(str(test_file), "test.exe")

    def test_file_hash_deterministic(self, tmp_path):
        test_file = tmp_path / "test.txt"
        test_file.write_text("same content")
        r1 = process_upload(str(test_file), "test.txt")
        r2 = process_upload(str(test_file), "test.txt")
        assert r1["file_hash"] == r2["file_hash"]
