"""
test_auth.py — Authentication Tests
=====================================
Tests for master password authentication, hashing, and key derivation.
"""

import os
import tempfile

import pytest

# Set up test config before importing modules
os.environ["FLASK_SECRET_KEY"] = "test-secret-key-for-testing-only"

import auth
from config import Config


@pytest.fixture(autouse=True)
def temp_password_file(tmp_path):
    """Use a temporary password hash file for each test."""
    test_file = str(tmp_path / ".password_hash")
    Config.PASSWORD_HASH_FILE = test_file
    yield test_file


class TestAuth:
    def test_is_first_run_no_file(self):
        """First run should be detected when no password file exists."""
        assert auth.is_first_run() is True

    def test_create_password(self):
        """Creating a password should store a hash file."""
        auth.create_password("testpassword123")
        assert auth.is_first_run() is False

    def test_verify_password_correct(self):
        """Correct password should verify successfully."""
        auth.create_password("mySecurePass!")
        assert auth.verify_password("mySecurePass!") is True

    def test_verify_password_incorrect(self):
        """Incorrect password should fail verification."""
        auth.create_password("mySecurePass!")
        assert auth.verify_password("wrongPassword") is False

    def test_password_too_short(self):
        """Password shorter than 8 chars should raise ValueError."""
        with pytest.raises(ValueError):
            auth.create_password("short")

    def test_derive_db_key(self):
        """Key derivation should produce a hex string."""
        key = auth.derive_db_key("testpassword")
        assert isinstance(key, str)
        assert len(key) == 64  # SHA-256 produces 32 bytes = 64 hex chars

    def test_derive_db_key_deterministic(self):
        """Same password should produce the same key."""
        key1 = auth.derive_db_key("testpassword")
        key2 = auth.derive_db_key("testpassword")
        assert key1 == key2

    def test_derive_db_key_different_passwords(self):
        """Different passwords should produce different keys."""
        key1 = auth.derive_db_key("password1")
        key2 = auth.derive_db_key("password2")
        assert key1 != key2
