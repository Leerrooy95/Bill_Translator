"""
test_fact_checker.py — Fact Checker Tests
==========================================
Tests for claim verification (mocked API calls).
"""

import os
from unittest.mock import MagicMock, patch

os.environ["FLASK_SECRET_KEY"] = "test-secret-key-for-testing-only"

import fact_checker


class TestBraveSearch:
    @patch("fact_checker.requests.get")
    def test_brave_search_success(self, mock_get):
        """Brave search should return structured results."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "web": {
                "results": [
                    {
                        "title": "Test Result",
                        "url": "https://example.com",
                        "description": "A test result.",
                    }
                ]
            }
        }
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response

        results = fact_checker._brave_search("test query", "fake-key")
        assert len(results) == 1
        assert results[0]["title"] == "Test Result"

    @patch("fact_checker.requests.get")
    def test_brave_search_failure(self, mock_get):
        """Brave search should return empty list on failure."""
        import requests as req
        mock_get.side_effect = req.RequestException("Network error")
        results = fact_checker._brave_search("test query", "fake-key")
        assert results == []


class TestVerifyClaim:
    @patch("fact_checker._brave_search")
    def test_verify_claim_verified(self, mock_search):
        """Verify claim should return a structured result."""
        mock_search.return_value = [
            {"title": "Source", "url": "https://example.com", "description": "Evidence"}
        ]

        with patch("anthropic.Anthropic") as mock_anthropic_cls:
            mock_client = MagicMock()
            mock_anthropic_cls.return_value = mock_client
            mock_response = MagicMock()
            mock_response.content = [
                MagicMock(text="VERDICT: VERIFIED\nCONFIDENCE: HIGH\nEXPLANATION: Confirmed.\nSOURCES: https://example.com")
            ]
            mock_client.messages.create.return_value = mock_response

            result = fact_checker.verify_claim("The sky is blue", "key", "brave-key")

            assert result["verdict"] == "VERIFIED"
            assert result["confidence"] == "HIGH"
            assert result["claim"] == "The sky is blue"

    @patch("fact_checker._brave_search")
    def test_verify_claim_no_evidence(self, mock_search):
        """No search results should return INSUFFICIENT_DATA."""
        mock_search.return_value = []

        result = fact_checker.verify_claim("Unknown claim", "key", "brave-key")

        assert result["verdict"] == "INSUFFICIENT_DATA"
        assert result["confidence"] == "LOW"
