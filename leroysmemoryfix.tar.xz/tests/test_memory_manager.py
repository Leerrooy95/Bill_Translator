"""
test_memory_manager.py — Memory Manager Tests
===============================================
Tests for context assembly, system prompt building, and conversation retrieval.
"""

import os
import sqlite3

import pytest

os.environ["FLASK_SECRET_KEY"] = "test-secret-key-for-testing-only"

import models
import memory_manager


@pytest.fixture
def db():
    """Create an in-memory database for testing."""
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    models.init_db(conn)
    yield conn
    conn.close()


@pytest.fixture
def case_with_data(db):
    """Create a case with documents, facts, timeline, and entities."""
    case_id = models.create_case(db, "Test v. State", "Test notes")
    doc_id = models.add_document(db, case_id, "report.pdf", "pdf", "Full text here.", "Summary of report.")
    models.add_fact(db, case_id, "Defendant was at location X at time Y", "report.pdf", "HIGH")
    models.add_timeline_event(db, case_id, "Arrest occurred", "2026-01-15", "arrest", "report.pdf")
    models.add_entity(db, case_id, "person", "John Smith", doc_id, "context text", 0.95)
    models.add_entity(db, case_id, "statute", "Ark. Code § 5-10-103", doc_id, "statute context", 0.8)
    models.add_conversation(db, case_id, "user", "What happened?", "analysis")
    models.add_conversation(db, case_id, "assistant", "Based on the report...", "analysis")
    return case_id


class TestBuildSystemPrompt:
    def test_empty_case(self, db):
        case_id = models.create_case(db, "Empty Case")
        prompt = memory_manager.build_system_prompt(db, case_id)
        assert "legal case analysis assistant" in prompt.lower()
        assert "Empty Case" in prompt

    def test_case_with_data(self, db, case_with_data):
        prompt = memory_manager.build_system_prompt(db, case_with_data)
        assert "Test v. State" in prompt
        assert "report.pdf" in prompt
        assert "Defendant was at location X" in prompt
        assert "2026-01-15" in prompt
        assert "John Smith" in prompt
        assert "Ark. Code" in prompt

    def test_analysis_mode(self, db, case_with_data):
        prompt = memory_manager.build_system_prompt(db, case_with_data, mode="analysis")
        assert "ANALYSIS" in prompt

    def test_research_mode(self, db, case_with_data):
        prompt = memory_manager.build_system_prompt(db, case_with_data, mode="research")
        assert "RESEARCH" in prompt

    def test_drafting_mode(self, db, case_with_data):
        prompt = memory_manager.build_system_prompt(db, case_with_data, mode="drafting")
        assert "DRAFTING" in prompt

    def test_plain_language_mode(self, db, case_with_data):
        prompt = memory_manager.build_system_prompt(db, case_with_data, mode="plain_language")
        assert "PLAIN LANGUAGE" in prompt

    def test_nonexistent_case(self, db):
        prompt = memory_manager.build_system_prompt(db, 999)
        assert "legal case analysis assistant" in prompt.lower()


class TestConversationContext:
    def test_get_conversations(self, db, case_with_data):
        messages = memory_manager.get_conversation_context(db, case_with_data)
        assert len(messages) == 2
        assert messages[0]["role"] == "user"
        assert messages[1]["role"] == "assistant"

    def test_empty_conversations(self, db):
        case_id = models.create_case(db, "No Chat")
        messages = memory_manager.get_conversation_context(db, case_id)
        assert len(messages) == 0
