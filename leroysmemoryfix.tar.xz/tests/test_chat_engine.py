"""
test_chat_engine.py — Chat Engine Tests
=========================================
Tests for chat context assembly (mocked API calls).
"""

import os
import sqlite3
from unittest.mock import MagicMock, patch

import pytest

os.environ["FLASK_SECRET_KEY"] = "test-secret-key-for-testing-only"

import models
import chat_engine


@pytest.fixture
def db():
    """Create an in-memory database for testing."""
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    models.init_db(conn)
    yield conn
    conn.close()


class TestChat:
    @patch("chat_engine.anthropic.Anthropic")
    def test_chat_stores_messages(self, mock_anthropic_cls, db):
        """Chat should store both user and assistant messages."""
        # Mock the API response
        mock_client = MagicMock()
        mock_anthropic_cls.return_value = mock_client
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="I'll analyze the case.")]
        mock_client.messages.create.return_value = mock_response

        case_id = models.create_case(db, "Test Case")

        response = chat_engine.chat(
            conn=db,
            case_id=case_id,
            user_message="What are the key issues?",
            api_key="test-key",
            mode="analysis",
        )

        assert response == "I'll analyze the case."

        # Check messages were stored
        conversations = models.get_conversations(db, case_id)
        assert len(conversations) == 2
        assert conversations[0]["role"] == "user"
        assert conversations[0]["content"] == "What are the key issues?"
        assert conversations[1]["role"] == "assistant"

    @patch("chat_engine.anthropic.Anthropic")
    def test_chat_includes_system_prompt(self, mock_anthropic_cls, db):
        """Chat should include case context in the system prompt."""
        mock_client = MagicMock()
        mock_anthropic_cls.return_value = mock_client
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="Analysis here.")]
        mock_client.messages.create.return_value = mock_response

        case_id = models.create_case(db, "Smith v. State")

        chat_engine.chat(
            conn=db,
            case_id=case_id,
            user_message="Analyze this",
            api_key="test-key",
        )

        # Verify the API was called with a system prompt containing the case name
        call_kwargs = mock_client.messages.create.call_args
        assert "Smith v. State" in call_kwargs.kwargs["system"]


class TestSummarizeDocument:
    @patch("chat_engine.anthropic.Anthropic")
    def test_summarize_stores_summary(self, mock_anthropic_cls, db):
        """Summarization should update the document's summary field."""
        mock_client = MagicMock()
        mock_anthropic_cls.return_value = mock_client
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="This is a police report summary.")]
        mock_client.messages.create.return_value = mock_response

        case_id = models.create_case(db, "Test Case")
        doc_id = models.add_document(db, case_id, "report.pdf", "pdf", "Full text of report.")

        summary = chat_engine.summarize_document(db, case_id, doc_id, "test-key")

        assert "police report summary" in summary

        # Check summary was stored
        doc = models.get_document(db, doc_id)
        assert doc["summary"] == "This is a police report summary."
