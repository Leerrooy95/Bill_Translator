"""
plain_language.py — Plain Language Translation Engine
======================================================
Adapted from the Bill Translator's readability engine.
Translates legal text to 8th-grade reading level using
Textstat (Flesch-Kincaid) + Claude.
"""

import logging

logger = logging.getLogger(__name__)

try:
    import textstat

    _HAS_TEXTSTAT = True
except ImportError:
    _HAS_TEXTSTAT = False
    logger.warning("textstat not installed. Readability scoring disabled.")

# Target reading level
TARGET_GRADE = 8.0
MAX_ITERATIONS = 3


def get_readability_score(text: str) -> dict:
    """
    Calculate readability metrics for text.
    Returns a dict with Flesch-Kincaid grade level and other scores.
    """
    if not _HAS_TEXTSTAT or not text.strip():
        return {"grade_level": None, "reading_ease": None, "available": False}

    return {
        "grade_level": textstat.flesch_kincaid_grade(text),
        "reading_ease": textstat.flesch_reading_ease(text),
        "available": True,
    }


def translate_to_plain_language(
    text: str,
    api_key: str,
    model: str = "claude-sonnet-4-6",
    target_grade: float = TARGET_GRADE,
) -> dict:
    """
    Translate legal text to plain language at the target reading level.

    Uses an iterative approach:
    1. Ask Claude to simplify the text
    2. Score readability
    3. If above target, re-iterate with feedback
    4. Return the simplified text with readability scores

    Returns:
      - original_text: the input text
      - plain_text: the simplified text
      - original_grade: reading level of original
      - final_grade: reading level of simplified version
      - iterations: number of simplification passes
    """
    import anthropic

    original_score = get_readability_score(text)
    original_grade = original_score.get("grade_level")

    # If already at target level, return as-is
    if original_grade is not None and original_grade <= target_grade:
        return {
            "original_text": text,
            "plain_text": text,
            "original_grade": original_grade,
            "final_grade": original_grade,
            "iterations": 0,
        }

    client = anthropic.Anthropic(api_key=api_key)
    current_text = text
    iterations = 0

    for i in range(MAX_ITERATIONS):
        iterations = i + 1

        grade_info = ""
        if _HAS_TEXTSTAT:
            current_grade = textstat.flesch_kincaid_grade(current_text)
            grade_info = (
                f"The current text is at a grade {current_grade:.1f} reading level. "
                f"Target is grade {target_grade:.1f} or below. "
            )

        prompt = (
            f"Rewrite the following legal text in plain language that someone with "
            f"an 8th-grade education can understand. {grade_info}\n\n"
            f"RULES:\n"
            f"- Use short sentences (under 20 words each)\n"
            f"- Use common, everyday words\n"
            f"- When you must use a legal term, define it in parentheses immediately after\n"
            f"- Keep all factual content — do not omit important information\n"
            f"- Use concrete examples where helpful\n"
            f"- Break complex ideas into simple steps\n\n"
            f"TEXT TO SIMPLIFY:\n{current_text}\n\n"
            f"PLAIN LANGUAGE VERSION:"
        )

        try:
            response = client.messages.create(
                model=model,
                max_tokens=4096,
                messages=[{"role": "user", "content": prompt}],
            )
            current_text = response.content[0].text
        except Exception as e:
            logger.error("Plain language translation failed: %s", e)
            break

        # Check if we've reached the target
        if _HAS_TEXTSTAT:
            new_grade = textstat.flesch_kincaid_grade(current_text)
            if new_grade <= target_grade:
                break

    final_score = get_readability_score(current_text)
    return {
        "original_text": text,
        "plain_text": current_text,
        "original_grade": original_grade,
        "final_grade": final_score.get("grade_level"),
        "iterations": iterations,
    }
