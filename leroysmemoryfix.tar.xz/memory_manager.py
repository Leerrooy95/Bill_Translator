"""
memory_manager.py — Per-Case Persistent Memory & Context Assembly
==================================================================
The core innovation: manages what case context gets injected into
Claude's system prompt on each message. Handles context window
management to stay within token limits.
"""

import logging

import models

logger = logging.getLogger(__name__)

# Context budget (approximate character counts → tokens ≈ chars/4)
MAX_CONTEXT_CHARS = 80_000  # ~20K tokens for context, leaving room for response
RECENT_MESSAGES = 20
DOC_SUMMARY_MAX = 2000  # Max chars per document summary in context


def build_system_prompt(conn, case_id: int, mode: str = "analysis") -> str:
    """
    Build the full system prompt for a case, including:
    - Case metadata
    - Document summaries
    - Extracted facts
    - Timeline
    - Entities
    - Mode-specific instructions
    """
    case = models.get_case(conn, case_id)
    if not case:
        return _base_instructions(mode)

    sections = []

    # ── Base role ──
    sections.append(_base_instructions(mode))

    # ── Case metadata ──
    sections.append(
        f"[CASE METADATA]\n"
        f"Name: {case['name']}\n"
        f"Status: {case['status']}\n"
        f"Created: {case['created_at']}\n"
        f"Notes: {case.get('notes', 'None')}"
    )

    # ── Document summaries ──
    docs = models.get_documents(conn, case_id)
    if docs:
        doc_lines = []
        for i, doc in enumerate(docs, 1):
            summary = (doc.get("summary") or "No summary yet")[:DOC_SUMMARY_MAX]
            doc_lines.append(f"{i}. {doc['filename']} ({doc['file_type']}) — {summary}")
        sections.append("[DOCUMENTS]\n" + "\n".join(doc_lines))

    # ── Extracted facts ──
    facts = models.get_facts(conn, case_id)
    if facts:
        fact_lines = []
        for f in facts:
            verified = "✓" if f.get("verified") else "?"
            fact_lines.append(
                f"- [{verified}] {f['fact_text']} (confidence: {f.get('confidence', 'N/A')})"
            )
        sections.append("[EXTRACTED FACTS]\n" + "\n".join(fact_lines))

    # ── Timeline ──
    timeline = models.get_timeline(conn, case_id)
    if timeline:
        tl_lines = []
        for t in timeline:
            date_str = t.get("event_date") or "Unknown date"
            tl_lines.append(f"{date_str}: {t.get('event_type', '')} — {t['description']}")
        sections.append("[TIMELINE]\n" + "\n".join(tl_lines))

    # ── Entities ──
    entities = models.get_entities(conn, case_id)
    if entities:
        # Group by type
        by_type: dict[str, list[str]] = {}
        for e in entities:
            etype = e.get("entity_type", "other")
            by_type.setdefault(etype, []).append(e["entity_name"])
        ent_lines = []
        for etype, names in by_type.items():
            unique = sorted(set(names))
            ent_lines.append(f"{etype.title()}: {', '.join(unique)}")
        sections.append("[ENTITIES]\n" + "\n".join(ent_lines))

    # ── Assemble and truncate ──
    full_prompt = "\n\n".join(sections)
    if len(full_prompt) > MAX_CONTEXT_CHARS:
        full_prompt = full_prompt[:MAX_CONTEXT_CHARS] + "\n\n[Context truncated due to length]"

    return full_prompt


def get_conversation_context(conn, case_id: int, limit: int = RECENT_MESSAGES) -> list[dict]:
    """
    Get recent conversation messages formatted for the Anthropic Messages API.
    Returns list of {"role": "user"|"assistant", "content": "..."}.
    """
    conversations = models.get_conversations(conn, case_id, limit=limit)
    messages = []
    for c in conversations:
        messages.append({"role": c["role"], "content": c["content"]})
    return messages


def _base_instructions(mode: str) -> str:
    """Return mode-specific base instructions for the system prompt."""
    base = (
        "You are a legal case analysis assistant for the Accountability Agent. "
        "You help analyze legal cases, identify contradictions, research law, "
        "and draft documents. You have access to the case files described below.\n\n"
        "CRITICAL RULES:\n"
        "- Always cite specific documents when making claims about the case\n"
        "- Flag contradictions between documents\n"
        "- When unsure, say so explicitly\n"
        "- Never fabricate case law or statutes\n"
        "- Provide confidence ratings (HIGH/MEDIUM/LOW) on analytical claims\n"
    )

    mode_instructions = {
        "analysis": (
            "MODE: ANALYSIS\n"
            "Focus on deep case analysis: identify contradictions, weaknesses in "
            "arguments, missing evidence, and strategic opportunities. Be thorough "
            "and cite specific documents for every claim."
        ),
        "research": (
            "MODE: LEGAL RESEARCH\n"
            "Focus on finding relevant statutes, case law, and precedents. "
            "Always provide full citations. Cross-reference findings with the "
            "specific facts of this case. Note which jurisdiction applies."
        ),
        "drafting": (
            "MODE: LEGAL DRAFTING\n"
            "Generate legal documents: motions, briefs, letters, cross-examination "
            "questions. Use formal legal language and proper formatting. Always "
            "include relevant case law citations and statutory references."
        ),
        "plain_language": (
            "MODE: PLAIN LANGUAGE\n"
            "Explain everything at an 8th-grade reading level. Use short sentences, "
            "common words, and concrete examples. Avoid legal jargon — when you must "
            "use a legal term, define it immediately in parentheses."
        ),
        "fact_check": (
            "MODE: FACT CHECK\n"
            "Verify specific claims against the case documents and known facts. "
            "Rate each claim as VERIFIED, UNVERIFIED, or CONTRADICTED. Provide "
            "the source for your determination."
        ),
    }

    return base + "\n" + mode_instructions.get(mode, mode_instructions["analysis"])
