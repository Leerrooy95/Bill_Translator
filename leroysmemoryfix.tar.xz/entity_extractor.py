"""
entity_extractor.py — Entity Extraction for Legal Documents
=============================================================
Adapted from the Live Trackers pipeline's entity_extractor.py.
Extracts legal entities (persons, organizations, statutes, dates,
locations) from document text. Uses GLiNER2 when available,
falls back to Claude-based extraction.
"""

import logging
import re

import models

logger = logging.getLogger(__name__)

# Try to import GLiNER2
try:
    from gliner import GLiNER

    _HAS_GLINER = True
    _gliner_model = None
    logger.info("GLiNER available for entity extraction.")
except ImportError:
    _HAS_GLINER = False
    logger.warning("GLiNER not installed. Will use Claude-based extraction only.")

# Legal entity types for GLiNER
LEGAL_ENTITY_TYPES = [
    "person",
    "organization",
    "location",
    "date",
    "statute",
    "case_citation",
    "court",
    "jurisdiction",
]


def _get_gliner_model():
    """Lazy-load GLiNER model to avoid slow startup."""
    global _gliner_model
    if _gliner_model is None and _HAS_GLINER:
        try:
            _gliner_model = GLiNER.from_pretrained("urchade/gliner_base")
            logger.info("GLiNER model loaded successfully.")
        except Exception as e:
            logger.error("Failed to load GLiNER model: %s", e)
    return _gliner_model


def extract_entities_gliner(text: str) -> list[dict]:
    """
    Extract entities using GLiNER2 (local, zero-cost).
    Returns list of {"entity_type", "entity_name", "confidence", "context"}.
    """
    model = _get_gliner_model()
    if model is None:
        return []

    # GLiNER works best with chunks; split on paragraphs
    chunks = [c.strip() for c in text.split("\n\n") if c.strip()]
    all_entities = []

    for chunk in chunks[:50]:  # Limit chunks to avoid timeout
        if len(chunk) < 10:
            continue
        try:
            results = model.predict_entities(
                chunk[:2000],  # GLiNER chunk size limit
                LEGAL_ENTITY_TYPES,
                threshold=0.3,
            )
            for entity in results:
                all_entities.append(
                    {
                        "entity_type": entity.get("label", "unknown"),
                        "entity_name": entity.get("text", ""),
                        "confidence": entity.get("score", 0.0),
                        "context": chunk[:200],
                    }
                )
        except Exception as e:
            logger.warning("GLiNER extraction failed on chunk: %s", e)

    return _deduplicate_entities(all_entities)


def extract_entities_regex(text: str) -> list[dict]:
    """
    Fallback regex-based entity extraction for common legal patterns.
    Not as good as GLiNER or Claude but works without any dependencies.
    """
    entities = []

    # Statute patterns (e.g., "Ark. Code § 5-10-103", "42 U.S.C. § 1983")
    statute_patterns = [
        r"(?:Ark\.|Arkansas)\s+Code\s+(?:Ann\.\s+)?§\s*[\d\-]+(?:\([\w]+\))?",
        r"\d+\s+U\.S\.C\.\s+§\s*\d+",
        r"(?:Fed\.\s+R\.\s+(?:Civ|Crim|App)\.\s+P\.\s+\d+)",
    ]
    for pattern in statute_patterns:
        for match in re.finditer(pattern, text):
            entities.append(
                {
                    "entity_type": "statute",
                    "entity_name": match.group().strip(),
                    "confidence": 0.8,
                    "context": text[max(0, match.start() - 50) : match.end() + 50],
                }
            )

    # Case citation patterns (e.g., "Miranda v. Arizona, 384 U.S. 436")
    case_pattern = r"[A-Z][a-zA-Z]{1,40}\s+v\.\s+[A-Z][a-zA-Z]{1,40}(?:,\s{0,3}\d+\s+[A-Z][a-zA-Z.]{1,30}\s+\d+)?"
    for match in re.finditer(case_pattern, text):
        entities.append(
            {
                "entity_type": "case_citation",
                "entity_name": match.group().strip(),
                "confidence": 0.7,
                "context": text[max(0, match.start() - 50) : match.end() + 50],
            }
        )

    # Date patterns
    date_pattern = r"\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}\b"
    for match in re.finditer(date_pattern, text):
        entities.append(
            {
                "entity_type": "date",
                "entity_name": match.group().strip(),
                "confidence": 0.9,
                "context": text[max(0, match.start() - 50) : match.end() + 50],
            }
        )

    return _deduplicate_entities(entities)


def extract_and_store(conn, case_id: int, document_id: int, text: str) -> list[dict]:
    """
    Extract entities from text and store them in the database.
    Uses GLiNER if available, falls back to regex.
    """
    # Try GLiNER first
    entities = extract_entities_gliner(text) if _HAS_GLINER else []

    # Always run regex for statute/citation patterns (GLiNER may miss these)
    regex_entities = extract_entities_regex(text)

    # Merge, preferring GLiNER when duplicates exist
    seen = {(e["entity_type"], e["entity_name"].lower()) for e in entities}
    for re_ent in regex_entities:
        key = (re_ent["entity_type"], re_ent["entity_name"].lower())
        if key not in seen:
            entities.append(re_ent)
            seen.add(key)

    # Store in database
    for entity in entities:
        models.add_entity(
            conn,
            case_id=case_id,
            entity_type=entity["entity_type"],
            entity_name=entity["entity_name"],
            document_id=document_id,
            context=entity.get("context", ""),
            confidence=entity.get("confidence", 0.5),
        )

    logger.info("Extracted %d entities from document %d", len(entities), document_id)
    return entities


def _deduplicate_entities(entities: list[dict]) -> list[dict]:
    """Remove duplicate entities, keeping highest confidence."""
    best: dict[tuple, dict] = {}
    for e in entities:
        key = (e["entity_type"], e["entity_name"].lower().strip())
        if key not in best or e.get("confidence", 0) > best[key].get("confidence", 0):
            best[key] = e
    return list(best.values())
