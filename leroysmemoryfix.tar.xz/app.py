"""
app.py — Accountability Agent Flask Application
=================================================
Main entry point. Handles routing, authentication, case management,
document uploads, chat interface, and API key management.
"""

import logging
import os
import threading
from datetime import timedelta
from functools import wraps

from flask import (
    Flask,
    flash,
    g,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

import auth
import chat_engine
import document_processor
import entity_extractor
import fact_checker
import legal_researcher
import memory_manager
import models
import plain_language
from config import Config

# ─── APP FACTORY ──────────────────────────────────────────────────────────────

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


def create_app() -> Flask:
    """Create and configure the Flask application."""
    app = Flask(__name__)
    app.config.from_object(Config)
    app.permanent_session_lifetime = timedelta(hours=Config.SESSION_LIFETIME_HOURS)

    # ── Security headers ──
    @app.after_request
    def set_security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; "
            "font-src 'self'; "
            "connect-src 'self'"
        )
        return response

    # ── Database connection management ──
    @app.before_request
    def open_db():
        if "db_key" in session:
            g.db = models.get_connection(Config.DATABASE_PATH, session["db_key"])
            models.init_db(g.db)
        else:
            g.db = None

    @app.teardown_appcontext
    def close_db(exception):
        db = getattr(g, "db", None)
        if db is not None:
            db.close()

    # ── Register routes ──
    _register_auth_routes(app)
    _register_case_routes(app)
    _register_chat_routes(app)
    _register_document_routes(app)
    _register_api_routes(app)

    return app


# ─── AUTH DECORATOR ───────────────────────────────────────────────────────────


def login_required(f):
    """Decorator to require authentication."""

    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("authenticated"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)

    return decorated


def api_keys_required(f):
    """Decorator to require API keys are set."""

    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("anthropic_key"):
            flash("Please enter your API keys first.", "warning")
            return redirect(url_for("api_keys"))
        return f(*args, **kwargs)

    return decorated


# ─── AUTH ROUTES ──────────────────────────────────────────────────────────────


def _register_auth_routes(app: Flask):
    @app.route("/")
    def index():
        if session.get("authenticated"):
            return redirect(url_for("dashboard"))
        if auth.is_first_run():
            return redirect(url_for("setup"))
        return redirect(url_for("login"))

    @app.route("/setup", methods=["GET", "POST"])
    def setup():
        if not auth.is_first_run():
            return redirect(url_for("login"))
        if request.method == "POST":
            password = request.form.get("password", "")
            confirm = request.form.get("confirm", "")
            if password != confirm:
                flash("Passwords do not match.", "error")
                return render_template("setup.html")
            try:
                auth.create_password(password)
                flash("Master password created. Please log in.", "success")
                return redirect(url_for("login"))
            except ValueError as e:
                flash(str(e), "error")
                return render_template("setup.html")
        return render_template("setup.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if auth.is_first_run():
            return redirect(url_for("setup"))
        if request.method == "POST":
            password = request.form.get("password", "")
            if auth.verify_password(password):
                session.permanent = True
                session["authenticated"] = True
                session["db_key"] = auth.derive_db_key(password)
                return redirect(url_for("api_keys"))
            else:
                flash("Invalid password.", "error")
        return render_template("login.html")

    @app.route("/api-keys", methods=["GET", "POST"])
    @login_required
    def api_keys():
        if request.method == "POST":
            anthropic_key = request.form.get("anthropic_key", "").strip()
            brave_key = request.form.get("brave_key", "").strip()
            if anthropic_key:
                session["anthropic_key"] = anthropic_key
            if brave_key:
                session["brave_key"] = brave_key
            if anthropic_key:
                flash("API keys saved for this session.", "success")
                return redirect(url_for("dashboard"))
            else:
                flash("Anthropic API key is required.", "error")
        return render_template(
            "api_keys.html",
            has_anthropic=bool(session.get("anthropic_key")),
            has_brave=bool(session.get("brave_key")),
        )

    @app.route("/logout")
    def logout():
        session.clear()
        flash("Logged out.", "success")
        return redirect(url_for("login"))


# ─── CASE ROUTES ─────────────────────────────────────────────────────────────


def _register_case_routes(app: Flask):
    @app.route("/dashboard")
    @login_required
    def dashboard():
        if g.db is None:
            flash("Database not available.", "error")
            return redirect(url_for("login"))
        cases = models.list_cases(g.db, status="active")
        archived = models.list_cases(g.db, status="archived")
        return render_template("dashboard.html", cases=cases, archived=archived)

    @app.route("/cases/new", methods=["POST"])
    @login_required
    def new_case():
        name = request.form.get("name", "").strip()
        notes = request.form.get("notes", "").strip()
        if not name:
            flash("Case name is required.", "error")
            return redirect(url_for("dashboard"))
        case_id = models.create_case(g.db, name, notes)
        flash(f"Case '{name}' created.", "success")
        return redirect(url_for("case_view", case_id=case_id))

    @app.route("/cases/<int:case_id>")
    @login_required
    def case_view(case_id):
        case = models.get_case(g.db, case_id)
        if not case:
            flash("Case not found.", "error")
            return redirect(url_for("dashboard"))
        docs = models.get_documents(g.db, case_id)
        facts = models.get_facts(g.db, case_id)
        timeline = models.get_timeline(g.db, case_id)
        entities = models.get_entities(g.db, case_id)
        conversations = models.get_conversations(g.db, case_id, limit=50)
        return render_template(
            "case.html",
            case=case,
            documents=docs,
            facts=facts,
            timeline=timeline,
            entities=entities,
            conversations=conversations,
            has_anthropic=bool(session.get("anthropic_key")),
            has_brave=bool(session.get("brave_key")),
        )

    @app.route("/cases/<int:case_id>/archive", methods=["POST"])
    @login_required
    def archive_case(case_id):
        models.update_case(g.db, case_id, status="archived")
        flash("Case archived.", "success")
        return redirect(url_for("dashboard"))

    @app.route("/cases/<int:case_id>/reopen", methods=["POST"])
    @login_required
    def reopen_case(case_id):
        models.update_case(g.db, case_id, status="active")
        flash("Case reopened.", "success")
        return redirect(url_for("dashboard"))

    @app.route("/cases/<int:case_id>/delete", methods=["POST"])
    @login_required
    def delete_case(case_id):
        models.delete_case(g.db, case_id)
        flash("Case permanently deleted.", "success")
        return redirect(url_for("dashboard"))

    @app.route("/cases/<int:case_id>/timeline/add", methods=["POST"])
    @login_required
    def add_timeline(case_id):
        description = request.form.get("description", "").strip()
        event_date = request.form.get("event_date", "").strip()
        event_type = request.form.get("event_type", "").strip()
        if description:
            models.add_timeline_event(
                g.db, case_id, description, event_date, event_type, source="manual"
            )
            flash("Timeline event added.", "success")
        return redirect(url_for("case_view", case_id=case_id))

    @app.route("/cases/<int:case_id>/facts/add", methods=["POST"])
    @login_required
    def add_fact(case_id):
        fact_text = request.form.get("fact_text", "").strip()
        if fact_text:
            models.add_fact(g.db, case_id, fact_text, source="manual", confidence="MEDIUM")
            flash("Fact added.", "success")
        return redirect(url_for("case_view", case_id=case_id))


# ─── CHAT ROUTES ─────────────────────────────────────────────────────────────


def _register_chat_routes(app: Flask):
    @app.route("/cases/<int:case_id>/chat", methods=["POST"])
    @login_required
    @api_keys_required
    def chat(case_id):
        message = request.form.get("message", "").strip()
        mode = request.form.get("mode", "analysis")

        if not message:
            return jsonify({"error": "Message is required."}), 400

        try:
            response_text = chat_engine.chat(
                conn=g.db,
                case_id=case_id,
                user_message=message,
                api_key=session["anthropic_key"],
                mode=mode,
                model=Config.ANTHROPIC_MODEL,
                max_tokens=Config.ANTHROPIC_MAX_TOKENS,
            )
            return jsonify({"response": response_text, "mode": mode})
        except RuntimeError:
            logger.exception("Chat error")
            return jsonify({"error": "An error occurred processing your message."}), 500

    @app.route("/cases/<int:case_id>/research", methods=["POST"])
    @login_required
    @api_keys_required
    def research(case_id):
        question = request.form.get("question", "").strip()
        if not question:
            return jsonify({"error": "Question is required."}), 400

        brave_key = session.get("brave_key", "")
        if not brave_key:
            return jsonify({"error": "Brave Search API key required for research."}), 400

        try:
            result = legal_researcher.research_legal_question(
                conn=g.db,
                case_id=case_id,
                question=question,
                anthropic_key=session["anthropic_key"],
                brave_key=brave_key,
                model=Config.ANTHROPIC_MODEL,
            )
            # Store as conversation
            models.add_conversation(g.db, case_id, "user", f"[RESEARCH] {question}", "research")
            models.add_conversation(g.db, case_id, "assistant", result, "research")
            return jsonify({"response": result, "mode": "research"})
        except RuntimeError:
            logger.exception("Research error")
            return jsonify({"error": "An error occurred during research."}), 500

    @app.route("/cases/<int:case_id>/fact-check", methods=["POST"])
    @login_required
    @api_keys_required
    def fact_check(case_id):
        claim = request.form.get("claim", "").strip()
        if not claim:
            return jsonify({"error": "Claim is required."}), 400

        brave_key = session.get("brave_key", "")
        if not brave_key:
            return jsonify({"error": "Brave Search API key required for fact checking."}), 400

        try:
            result = fact_checker.verify_claim(
                claim=claim,
                anthropic_key=session["anthropic_key"],
                brave_key=brave_key,
                model=Config.ANTHROPIC_MODEL,
            )
            return jsonify(result)
        except Exception:
            logger.exception("Fact check error")
            return jsonify({"error": "An error occurred during fact checking."}), 500

    @app.route("/cases/<int:case_id>/plain-language", methods=["POST"])
    @login_required
    @api_keys_required
    def translate_plain(case_id):
        text = request.form.get("text", "").strip()
        if not text:
            return jsonify({"error": "Text is required."}), 400

        try:
            result = plain_language.translate_to_plain_language(
                text=text,
                api_key=session["anthropic_key"],
                model=Config.ANTHROPIC_MODEL,
            )
            return jsonify(result)
        except Exception:
            logger.exception("Plain language translation error")
            return jsonify({"error": "An error occurred during translation."}), 500


# ─── DOCUMENT ROUTES ─────────────────────────────────────────────────────────


def _process_document_background(
    db_path: str,
    db_key: str | None,
    case_id: int,
    doc_id: int,
    raw_text: str,
    anthropic_key: str | None,
    model: str,
) -> None:
    """
    Run entity extraction and AI summarisation in a daemon thread so the
    upload HTTP request can return immediately without waiting for the
    potentially long-running Anthropic API call.
    """
    try:
        conn = models.get_connection(db_path, db_key)
        models.init_db(conn)
        try:
            entity_extractor.extract_and_store(conn, case_id, doc_id, raw_text)

            if anthropic_key:
                try:
                    chat_engine.summarize_document(
                        conn, case_id, doc_id, anthropic_key, model=model
                    )
                except Exception as e:
                    logger.warning("Background auto-summary failed: %s", e)

            conn.commit()
        finally:
            conn.close()
    except Exception as e:
        logger.error("Background document processing failed: %s", e)


def _register_document_routes(app: Flask):
    @app.route("/cases/<int:case_id>/upload", methods=["GET", "POST"])
    @login_required
    def upload(case_id):
        case = models.get_case(g.db, case_id)
        if not case:
            flash("Case not found.", "error")
            return redirect(url_for("dashboard"))

        if request.method == "POST":
            if "file" not in request.files:
                flash("No file selected.", "error")
                return redirect(url_for("upload", case_id=case_id))

            file = request.files["file"]
            if not file.filename:
                flash("No file selected.", "error")
                return redirect(url_for("upload", case_id=case_id))

            if not document_processor.allowed_file(file.filename):
                flash("File type not allowed. Use PDF, TXT, or MD files.", "error")
                return redirect(url_for("upload", case_id=case_id))

            try:
                # Save file
                save_path, original_name = document_processor.save_uploaded_file(
                    file, Config.UPLOAD_DIR
                )

                # Process file
                result = document_processor.process_upload(save_path, original_name)

                # Store in database
                doc_id = models.add_document(
                    g.db,
                    case_id=case_id,
                    filename=result["filename"],
                    file_type=result["file_type"],
                    raw_text=result["raw_text"],
                )
                g.db.commit()

                # Kick off heavy processing (entity extraction + AI summary)
                # in a background thread so the response is not blocked.
                thread = threading.Thread(
                    target=_process_document_background,
                    args=(
                        Config.DATABASE_PATH,
                        session.get("db_key"),
                        case_id,
                        doc_id,
                        result["raw_text"],
                        session.get("anthropic_key"),
                        Config.ANTHROPIC_MODEL,
                    ),
                    daemon=True,
                )
                thread.start()

                flash(f"'{original_name}' uploaded. Analysis is running in the background.", "success")
                return redirect(url_for("case_view", case_id=case_id))

            except Exception as e:
                logger.error("Upload failed: %s", e)
                flash(f"Upload failed: {e}", "error")
                return redirect(url_for("upload", case_id=case_id))

        return render_template("upload.html", case=case)

    @app.route("/cases/<int:case_id>/documents/<int:doc_id>")
    @login_required
    def view_document(case_id, doc_id):
        doc = models.get_document(g.db, doc_id)
        if not doc:
            flash("Document not found.", "error")
            return redirect(url_for("case_view", case_id=case_id))
        return jsonify(dict(doc))


# ─── API ROUTES (JSON) ───────────────────────────────────────────────────────


def _register_api_routes(app: Flask):
    @app.route("/api/cases/<int:case_id>/summary")
    @login_required
    def api_case_summary(case_id):
        """Return case summary data as JSON."""
        case = models.get_case(g.db, case_id)
        if not case:
            return jsonify({"error": "Case not found"}), 404
        return jsonify(
            {
                "case": case,
                "documents": models.get_documents(g.db, case_id),
                "facts": models.get_facts(g.db, case_id),
                "timeline": models.get_timeline(g.db, case_id),
                "entities": models.get_entities(g.db, case_id),
            }
        )


# ─── ENTRY POINT ─────────────────────────────────────────────────────────────

app = create_app()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_ENV") == "development"
    app.run(host="127.0.0.1", port=port, debug=debug)
