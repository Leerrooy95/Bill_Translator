# Copilot Suggestions for Accountability Agent

> Observations and improvement ideas noticed during the markdown rendering / copy-button work.  
> None of these are blocking — they're things that may be worth tackling next.

---

## Already Fixed in This PR
- **Markdown rendering** — agent responses now render headers, bold, italic, lists, code blocks, tables, blockquotes, and horizontal rules instead of showing raw `#` / `**` symbols.
- **Copy-to-clipboard button** — every chat message (including history loaded on page open) has a 📋 button in the message header. It fades in on hover to keep the UI clean.
- **Typing indicator** — three-dot animated indicator appears while waiting for the agent, so the UI doesn't appear frozen.

---

## Suggested Improvements

### 1. Plain-Language Mode Is Silently Misrouted
`app.js` sends **plain_language** mode through the generic `/chat` endpoint.  
There is a dedicated `/cases/<id>/plain-language` endpoint in `app.py` that calls the specialised `plain_language.translate_to_plain_language()` function directly.  
The frontend never uses it, so the dedicated endpoint is dead code.  
**Fix:** Add a `plain_language` branch in `app.js` (same pattern as `research` / `fact_check`) to POST to `/cases/${CASE_ID}/plain-language` with the field `text`.

---

### 2. Document Summaries Also Contain Raw Markdown
The **Documents** tab renders `doc.summary` as plain text inside a `white-space: pre-wrap` `<div>`.  
Summaries are AI-generated and typically contain headers and bullet points.  
**Fix:** Apply the same `renderMarkdown()` + `.rendered` class treatment to `.doc-summary` elements in `initExistingMessages()`.

---

### 3. No Visual Feedback When the Session Expires
Sessions expire after 2 hours (`SESSION_LIFETIME_HOURS`). A chat submission after expiry silently redirects to `/login`, which can look like a crash.  
**Fix:** Intercept non-JSON or redirect responses from `fetch()` in `initChat()` and show a friendly "Session expired — please log in again" message with a link to `/login`.

---

### 4. Conversations Are Capped at 50 With No Pagination
`models.get_conversations(g.db, case_id, limit=50)` is hardcoded.  
Older messages are silently dropped from the view with no "Load more" option.  
**Fix:** Add an offset-based "Load earlier messages" button, or increase the limit and add virtual scrolling.

---

### 5. No Timestamps on Chat Messages
The `conversations` table stores `created_at` but it is never passed to the Jinja template or rendered.  
**Fix:** Display a relative timestamp (e.g. "3 min ago") in the message header using a small helper like `Intl.RelativeTimeFormat`, and expose `created_at` in the template context.

---

### 6. Keyboard Shortcut Is Undocumented
`Ctrl+Enter` / `Cmd+Enter` to send a message is implemented but not shown anywhere in the UI.  
**Fix:** Add a small hint below the textarea, e.g. `Ctrl+Enter to send`.

---

### 7. Accessibility (ARIA) Gaps
- The tab bar has no `role="tablist"` / `role="tab"` / `aria-selected` attributes.
- Chat messages have no `role="log"` or `aria-live="polite"` on the message container, so screen readers won't announce new messages.
- The copy button has a `title` but no `aria-label`.
**Fix:** Add the appropriate ARIA roles and live-region attributes to the chat container and tab components.

---

### 8. No Export / Print Option
Users may want a PDF or text export of a case conversation.  
**Fix:** Add a `@media print` stylesheet and an "Export / Print" button that opens the browser print dialog with just the chat content visible, or generate a plain-text download via a Blob URL.

---

### 9. File Upload Has No Progress Feedback
Large PDFs can take several seconds to upload and process.  
After the POST the user just sees the same page until the redirect — there is no spinner or progress bar.  
**Fix:** Switch the upload form to AJAX, show an upload progress bar via `XMLHttpRequest.upload.onprogress`, then poll or redirect on completion.

---

### 10. Brave Search Key Missing → Silent Research Failure
If the user tries Research or Fact-Check mode without a Brave key, the server returns an error JSON.  
The error is displayed in the chat, but the mode select still shows those options as if they are available.  
**Fix:** When `has_brave` is `false`, visually disable the Research and Fact-Check options in the `<select>` and show a tooltip explaining that a Brave API key is required.

---

### 11. No Dark-Mode / Light-Mode Toggle
The app is locked to a dark theme.  
**Fix:** Add a CSS `prefers-color-scheme: light` media query (or a manual toggle button in the nav) with a light palette alternative.

---

### 12. CSP `unsafe-inline` for Scripts
`app.py` uses `script-src 'self' 'unsafe-inline'` to allow the inline `<script>const CASE_ID = ...;</script>` block in `case.html`.  
**Fix:** Pass `CASE_ID` as a `data-` attribute on a container element instead of a `<script>` block, then read it in `app.js`. This allows the CSP to drop `'unsafe-inline'` for scripts, tightening the policy.

---

*Last updated: April 2026*
